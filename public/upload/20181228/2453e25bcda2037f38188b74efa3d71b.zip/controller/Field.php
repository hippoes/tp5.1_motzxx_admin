<?php
namespace app\field\controller;
use user\Admin;
class Field extends Admin
{
	 public function __construct() {
        parent::__construct();	
		$this->F = new \files\File();
		
		$this->fieldAdd =NULL;
		$this->fieldDel =NULL;
		$this->fieldEdit =NULL;

    }
/*************************************************************
	field_list 字段列表
*************************************************************/	
    public function field_list()
    {
		$page = $this->request->param('page/d',1);
		$limit = $this->request->param('limit/d',20);
		$table = $this->request->param('table','');
		$keyword = $this->request->param('keyword','','trim');
		$where=NULL;

		if(!$table) $this->error(lang('err_param'));
		
		if($keyword)
		{
			$where = $keyword ? " (`title` LIKE '%".$keyword."%' or `field`='".$keyword."') AND `table`='".$table."' " : '1=1';
		}
		else
		{
			$where[] = ['table','=',$table]; 
		}

		$totalCount = db('field_table')->where($where)-> count();
		$info = db('field_table')->where($where) -> json(['property','administrator_auth','member_auth'])-> page($page,$limit) -> order(['order_num','id'=>'asc']) -> select ();
		
		$data['code'] = 0;
		$data['data'] = $info;
		$data['count'] = $totalCount;
		$data['msg'] = lang('not_data');
		
		if($this->request -> isAjax())
		{
			    return $data;
		}
		else
		{
			    $form_type = getFormType();
				
				$this->assign('form_type',$form_type);
			    $this->assign('table',$table);
				$this->assign('data',$data);
				return $this->fetch();
		}
    }

/*************************************************************
	field_add 字段添加
*************************************************************/	
    public function field_add()
    {

		$table = $this->request->param('table',"",'trim');

		if($this->request -> isAjax() || $this->request-> isPost())
		{
			    $param = $this->request->param();

				$field= trim($param['field']);
				$formType= trim($param['form_type']);

				if(!$table || !$field || !$formType)
				{
				    	$data= ['err'=>1,'content'=>lang('err_param')];
			            return $data;
				}
				$model = new \database\Model();
				if(!$model->table_has($table)) 
				{
				    	$data= ['err'=>1,'content'=>lang('field_table_p',['table'=>$table])];
			            return $data;					
				}
				
				$only =  fieldValueOnly($field,$table);
				if($only)
				{
				    	$data= ['err'=>1,'content'=>lang('field_exist_p')];
			            return $data;
				}
				
				if(!isset($param['property']['is_num'])) $param['property']['is_num'] = 0;
				if(!isset($param['property']['only'])) $param['property']['only'] = 0;
				if(!isset($param['property']['min_len'])) $param['property']['min_len'] = 0;
				if(!isset($param['status'])) $param['status'] = 0;
				
				$formTypePath = getFieldTemPath($formType);
				
				if($this->F->f_has($formTypePath."field.php") )  include_once $formTypePath."field.php"; 
                
				if(!$this->fieldAdd) include_once env('app_path')."field".DIRECTORY_SEPARATOR."field_tem".DIRECTORY_SEPARATOR."text".DIRECTORY_SEPARATOR."field.php";

				$insert = db('field_table')->json(['property','administrator_auth','member_auth']) ->strict(false)->insert($param);
				
				if($insert)
				{  
					  $exec_field = call_user_func_array($this ->fieldAdd,[$param]);
					  
					  if($exec_field)
					  {
						  $data= ['err'=>0,'content'=>lang('op_success')];
					  }
					  else
					  {
						  $data= ['err'=>1,'content'=>lang('err_param')];
					  }
					  return  json($data);
				}

		}
		else
		{
			    if(!$table) $this->error(lang('err_param'));
				$this->assign('table',$table);
				
			    $form_type = getFormType();
				$this->assign('form_type',$form_type);
				
				if(isInstall('administrator'))
				{
					 $adminGroup = exeFun('getAdministratorGroup',[],"administrator");
					 $this->assign('administratorGroup',$adminGroup);
				}
				
				if(isInstall('member'))
				{
					 $memberGroup = exeFun('getMemberGroup',[],"member");
					 $this->assign('memberGroup',$memberGroup);
				}
			    
                return $this->fetch();
		}
		
    }
	
/*************************************************************
	field_edit 字段编辑
*************************************************************/	
    public function field_edit()
    {
		
		$table = $this->request->param('table',"",'trim');
		$id = $this->request->param('id');
		$auth = $this->request->param('auth');

		if($this->request -> isAjax() || $this->request-> isPost())
		{
			    $param =$fieldParam= $this->request->param();

                if(!$id) return ['err'=>1,'content'=>lang('err_param')];
				
				if(isset($param['batch']) && $param['batch']) 
				{
					  $param = array_del_key($param,['id','field','form_type','table']);
					  $updateWhere[] = ['id','in',$id];
					  $update = db('field_table')->where($updateWhere) ->strict(false)->update($param);
					  
					  if($update!==false)
					  {
						  $data = ['err'=>0,'content'=>lang('op_success')];
					  } 
					  else
					  {
						  $data= ['err'=>1,'content'=>lang('err_fail')];
					  }
					  return $data;
				}
				
				$model = new \database\Model();
				if(!$model->table_has($table)) 
				{
				    	$data= ['err'=>1,'content'=>lang('field_table_p',['table'=>$table])];
			            return $data;					
				}
				$fieldInfo = getFieldInfo($id);
				
				$field= $fieldInfo['field'];
				$formType= $fieldInfo['form_type'];
				$table = $fieldInfo['table'];
				
				$fieldParam['field'] = $field;
				$fieldParam['form_type'] = $formType;
				$fieldParam['table'] = $table;

				if(!$table || !$field || !$formType)
				{
				    	$data= ['err'=>1,'content'=>lang('err_param')];
			            return $data;
				}
				
				if(!isset($param['property']['is_num'])) $param['property']['is_num'] = 0;
				if(!isset($param['property']['only'])) $param['property']['only'] = 0;
				if(!isset($param['property']['min_len'])) $param['property']['min_len'] = 0;
				if(!isset($param['status'])) $param['status'] = 0;
				if(!isset($param['administrator_auth'])) $param['administrator_auth'] = "";
				if(!isset($param['member_auth'])) $param['member_auth'] = "";
				
				$formTypePath = getFieldTemPath($formType);
				
				if($this->F->f_has($formTypePath."field.php") )  include_once $formTypePath."field.php"; 
                
				if(!$this->fieldEdit) include_once env('app_path')."field".DIRECTORY_SEPARATOR."field_tem".DIRECTORY_SEPARATOR."text".DIRECTORY_SEPARATOR."field.php";

                $param = array_del_key($param,['id','field','form_type','table']);
                $updateWhere[] = ['id','in',$id];
				
				if(isset($param['property']) && is_array($param['property']) && count($param['property']) > 0 )
				{
					$update = db('field_table')->where($updateWhere) -> json(['property','administrator_auth','member_auth']) ->strict(false)->update($param);
					$exec_field = call_user_func_array($this ->fieldEdit,[$fieldParam]);
					
					if($update!==false && $exec_field) return json(['err'=>0,'content'=>lang('op_success')]);
				}
				else
				{
					$update = db('field_table')->where($updateWhere)->json(['administrator_auth','member_auth']) ->strict(false)->update($param);
					if($update!==false) return json(['err'=>0,'content'=>lang('op_success')]);
				}
				
				$data= ['err'=>1,'content'=>lang('err_fail')];
				return  json($data);

		}
		else
		{
			    if(!$id) $this->error(lang('err_param'));

                $info = getFieldInfo($id);
				
				$this->assign('table',$info['table']);
				$this->assign('id',$id);
				
				if(!$info) $this->error(lang('err_info'));
				$this->assign('info',$info);
				
				$form_type = getFormType();
				$this->assign('form_type',$form_type);

				if(isInstall('administrator'))
				{
					 $adminGroup = exeFun('getAdministratorGroup',[],"administrator");
					 $this->assign('administratorGroup',$adminGroup);
				}
				
				if(isInstall('member'))
				{
					 $memberGroup = exeFun('getMemberGroup',[],"member");
					 $this->assign('memberGroup',$memberGroup);
				}
			    if($auth == 1)
				{
					return $this->fetch("field_auth");
				}
				else
				{
					return $this->fetch();
				}
                
		}
    }
	
/*************************************************************
	field_del 字段删除
*************************************************************/	
    public function field_del()
    {
		$id = $this->request->param('id','','trim');

		if(!$id)
		{
			 $data= ['err'=>1,'content'=>lang('err_param')];
			 return $data;
		}

		$where[] = ['id','in',$id];
		$where[] = ['isdel','<>',1];
		
		if($this->request-> isPost() || $this->request-> isAjax())
		{
			  $info = db('field_table') -> where($where) -> select();	
			  $delNum = 0 ; 

			  foreach($info as $v)
			  {
				    $delId = $v['id'];
                    $formType = $v['form_type'];
                    $formTypePath = getFieldTemPath($formType);
					if($this->F->f_has($formTypePath."field.php") )  include_once $formTypePath."field.php"; 
					if(!$this->fieldDel) include_once env('app_path')."field".DIRECTORY_SEPARATOR."field_tem".DIRECTORY_SEPARATOR."text".DIRECTORY_SEPARATOR."field.php";
					
					$exec_field = call_user_func_array($this ->fieldDel,[$v]);

					if($exec_field)
					{
						  	$delWhere =[['id','=',$delId]];
					        $del = db('field_table')->where($delWhere)->delete();
							
							if($del) $delNum++;
					}
					
					
					
			  }
			  
			  if($delNum > 0 )
			  { 
				   $data= ['err'=>0];
				   return $data;
			  }
			  else
			  {
				   $data= ['err'=>1,'content'=>lang('err_fail')];
				   return $data;
			  }			
		}
		else
		{
			  return $data= ['err'=>0];
		}
    }
/*************************************************************
	get_field_property 获取字段属性表达
*************************************************************/	
    public function get_field_property()
    {
		$formType = $this->request->param('type','','trim');
		$id = $this->request->param('id/d',0);

		if(!$formType) return['err'=>1,'content'=>lang('err_param')];

		$fieldWhere[] = ['sign','=',$formType];
		$form = db('field_form_type')->where($fieldWhere)->find();
		
		if(!$form)  return['err'=>1,'content'=>lang('err_param')];
		
		$module = $form['install_module'] ? $form['install_module'] : "field";
		
		if(!$id)
		{
			$temPath = env('app_path').$module.DIRECTORY_SEPARATOR."field_tem".DIRECTORY_SEPARATOR.$formType.DIRECTORY_SEPARATOR."add.html";
			$param=[];
		}
		else
		{
			$temPath = env('app_path').$module.DIRECTORY_SEPARATOR."field_tem".DIRECTORY_SEPARATOR.$formType.DIRECTORY_SEPARATOR."edit.html";
            $info = getFieldInfo($id);

			$param['property']=$info['property'];	
		}
		
		$temConfigPath = getFieldTemPath($formType);
		$fieldConfig = FF('config',NULL,$temConfigPath);
		
		$param['config'] = $fieldConfig;
		$content = $this->F->read($temPath);
		$content = $this->display($content,$param);
		$data = ['err'=>0,'content'=>$content];
		return $data;

    }	
}
