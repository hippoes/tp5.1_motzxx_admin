<?php
return[
     'height'=>[
	      'title'=>"编辑器高度",'default'=>300,'describe'=>'设置编辑器的高度'
	 ]
];