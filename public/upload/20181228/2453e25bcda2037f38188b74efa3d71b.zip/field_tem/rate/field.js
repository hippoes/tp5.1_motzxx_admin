// JavaScript Document
	layui.use(['jquery','jqbind','rate'],function(){
			var $ = layui.jquery,
			jqbind = layui.jqbind,
			rate = layui.rate,
			field=function(){
				
				this.options = {};
			}
		
				 /**
			 * @todo 星级绑定
		
			 * @param string call 回调的方法
			 */
			field.prototype.rate = function(obj) {
				var _this = this;
				params = getParams($(obj), "data-params", $);
				params = $.extend({}, _this.options, params);
				var show_text =params['show_text']=="1" ? true : false; //是否显示input
				var value = params['default'] ? parseFloat(params['default']) : 0;
				var half = params['half']=="1" ? true : false;
				var length = params['length'] ? parseInt(params['length']) : 5;
				var color = params['color'] ? params['color'] :  false;
		
				var input = params['input'] ? params['input'] :  "#"+$(obj).attr('id')+"_input";
				var option = {};
				
		
				 option['elem'] = obj;
				 option['value'] = value;  
				 option['length'] = length; 
				 if(color) option['theme'] = color;
				 if(show_text) option['text'] = true;
				 if(half) option['half'] = true;
				 
				 option['setText'] = function(vals){
					  this.span.text(vals);
					  $(input).val(vals);
				 }
				 
				 rate.render(option);
		
			}
			
				 /**
			 * @todo 星级绑定
		
			 * @param string call 回调的方法
			 */
			field.prototype.rateBind = function() {
				var _this = this;
				$(".rate:not([bind])").each(function() {
					jqbind.bind($(this));
					_this.rate(this);
				});
			}
					
			/**
			 * @todo 单文件上传
		
			 * @param string call 回调的方法
			 */
			field.prototype.init = function() {
				var _this = this;
				_this.rateBind();
			}
			
			
		   var rateBind = new field();
           rateBind.init();

   })