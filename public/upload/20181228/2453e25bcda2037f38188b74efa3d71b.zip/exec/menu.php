<?php

return [
		'menu_0'=>['title'=>'字段管理','ico'=>'layui-icon-table','order_num'=>0,'parent_id'=>4,'type'=>'admin'],
		'menu_1'=>['title'=>'表单类型','ico'=>'layui-icon-tabs','order_num'=>0,'parent_id'=>'menu_0','type'=>'admin','url'=>'field/Form/form_type_list'],
		'menu_2'=>['title'=>'字段测试','ico'=>'layui-icon-face-smile-b','order_num'=>0,'parent_id'=>'menu_0','type'=>'admin','url'=>'field/Field/field_list?table=field_ceshi']
];

