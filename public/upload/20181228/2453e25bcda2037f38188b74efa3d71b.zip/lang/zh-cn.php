<?php
// +----------------------------------------------------------------------
// | HisiPHP框架[基于ThinkPHP5开发]
// +----------------------------------------------------------------------
// | Copyright (c) 2016-2018 http://www.hisiphp.com
// +----------------------------------------------------------------------
// | HisiPHP承诺基础框架永久免费开源，您可用于学习和商用，但必须保留软件版权信息。
// +----------------------------------------------------------------------
// | Author: 橘子俊 <364666827@qq.com>，开发者QQ群：50304283
// +----------------------------------------------------------------------
// 中文语言包
return [
	'select_record'=>'请先选择操作的记录',
	'not_null'=>'为必填项，不能为空',
	'field_exist_p'=>'【字段名称】在数据表中存在，请重新输入',
	'field_table_p'=>'【{:table}】数据表不存在，请添加数据表',
	
	'int'=>'整数',
	'decimal_num'=>'位小数',
	
	'group_auth_disable'=>'禁用所有组',
	
	'group_admin_add'=>'管理组-权限-表单提交',
	'group_admin_edit'=>'管理组-权限-表单编辑',
	'group_admin_show'=>'管理组-权限-表单显示',
	
	'group_member_add'=>'用户组-权限-表单提交',
	'group_member_edit'=>'用户组-权限-表单编辑',
	'group_member_show'=>'用组-权限-表单显示',

	
	'group_admin_p'=>'温馨提示:如果不选择，表示全部可以操作，如果选禁用所有组，表示改操作下的所有组都不可以操作',
	

	// 字段
	'field'=>'字段',
	'field_title'=>'字段别名',
	'field_title_p'=>'改字段的表单名称，一般为汉字，比如标题，内容',
	'field_name'=>'字段名称',
	'field_name_p'=>'数据表中字段的名称，请使用英文字母数字',
	'field_sort_p'=>'字段排序顺序，越小越在前边',
	'field_group'=>'字段分组',
	'field_group_p'=>'在表单显示的时候，字段可以按照该标识分组',
	'field_describe'=>'字段描述',
	'field_form_type'=>'表单类型',
	'field_group'=>'字段分组',
	'field_only'=>'字段唯一',
	'field_table'=>'数据表',
	
	'field_property_css'=>'表单样式',
	'field_property_css_p'=>'在INPUT表单上的class',
	'field_property_default'=>'默认值',
	'field_property_default_p'=>'请填写选项值',
	'field_property_default_slider_p'=>'如果开启范围选择，请输入2个值，用英文逗号(,)隔开',
	'field_property_default_rate_p'=>'如果开启半星选项，可输入.5，否则必选输入整数',
	'field_property_default_check_p'=>'请填写选项值，多个值时，用英文的单引号(,)隔开',
	'field_property_default_tab_1'=>'手动输入',
	'field_property_default_tab_2'=>'变量获取',
	'field_property_default_tab_3'=>'数据库',
	'field_property_form_property'=>'其它属性',
	'field_property_form_property_p'=>'可以为INPUT表单加入其它属性，如onclick="a()"',
	'field_property_form_property_checkbox_p'=>'改变选框款式，待选：lay-skin=primary lay-skin=switch 留空',
	'field_property_reg'=>'表单正则',
	'field_property_reg_p'=>'正则匹配，格式为 ：表达式===提示信息,每行一对',
	'field_property_min_max_len'=>'字符个数',
	'field_property_min_max_len_p'=>'输入字符数，0：表示不限制',
	
	'field_property_min_max'=>'取值范围',
	'field_property_min_max_p'=>'0：表示不限制',
	
	'field_property_decimal_num'=>'小数位数',
	'field_property_num'=>'数字',
	'field_property_is_num'=>'是否数字',
	'field_property_is_num_p'=>'提示：如果字段内容确实为数字，请选择数字，方便排序查询',
	
	'field_property_only'=>'唯一',
	'field_property_only_not'=>'不唯一',
	'field_property_only_'=>'字段唯一',
	'field_property_only_p'=>'选择唯一：数据表中该字段的值不重复，比如：用户名字段',
	
    'field_tab_base'=>'基本设置',
	'field_tab_property'=>'属性设置',
	'field_tab_auth'=>'权限设置',
	
	'field_select_show_row'=>'显示行数',
	'field_select_show_row_p'=>'下拉类别显示的行数，默认为1行',
	
	'field_select_required'=>'是否必选',
	'field_select_num'=>'选择个数',
	'field_select_num_p'=>'最小选择个数-最大选择个数',
	'field_options'=>'选项值',
	'field_options_p'=>'选项值格式：text=value，每行一个，分组格式：分组起始 G=组名称，分组结束 G',
	'field_options_check_p'=>'选项值格式：text=value，每行一个',
	
	'field_slider_input'=>'输入框',
	'field_slider_input_p'=>'是否显示输入框,开启范围选择，该选择不生效',
	
	'field_slider_show'=>'显示方式',
	'field_slider_show_0'=>'横向',
	'field_slider_show_1'=>'纵向',
	
    'field_slider_range'=>'范围选择',
	'field_slider_range_p'=>'开启：选择数字的范围格式为（1,10）',
	'field_slider_showstep'=>'间隔点',
	'field_slider_showstep_p'=>'显示滑块拖动的预计位置',
	'field_slider_step'=>'滑块步长',
	'field_slider_step_p'=>'滑块每次拖动的距离',
	
	'field_slider_min_max_len_p'=>'滑块滑动范围',
	'field_slider_color'=>'滑块颜色',
	
	'field_rate_text'=>'文本显示',
	'field_rate_text_p'=>'启用：显示你选择的星级数字',
	'field_rate_half'=>'开启半星',
	'field_rate_half_p'=>'启用：可以选择半个星星，否则选择整个星星，不可以选择-.5',
	'field_rate_length'=>'星星个数',
	'field_rate_length_p'=>'显示星星的个数',
	'field_rate_color'=>'星星颜色',
	
	'field_colorpicker_default'=>'默认颜色',
	'field_colorpicker_preinstall'=>'预设颜色',
	'field_colorpicker_preinstall_p'=>'打开选择器时预设的颜色块',
	'field_colorpicker_preinstall_color_p'=>'多个颜色请用英文逗号(,)隔开，留空使用默认预设颜色块',
	
	'field_colorpicker_size'=>'框尺寸',
	'field_colorpicker_size_p'=>'设定选择颜色框尺寸',
	'field_colorpicker_lg'=>'大号',
	'field_colorpicker_sm'=>'中号',
	'field_colorpicker_xs'=>'小号',
	
	'field_colorpicker_alpha'=>'透明度',
	'field_colorpicker_alpha_p'=>'是否启用颜色透明度',
	
	'field_datetime_date'=>'日期',
	'field_datetime_time'=>'时间',
	'field_datetime_lang'=>'语言',
	'field_datetime_lang_0'=>'中文',
	'field_datetime_lang_1'=>'英文',
	
	'field_datetime_range'=>'日期区间',
	'field_datetime_range_0'=>'日期',
	'field_datetime_range_1'=>'区间',

	'field_datetime_format'=>'日期格式',
	'field_datetime_format_p'=>'时间日期格式：yyyy-年，MM-月,dd-日，HH-时，mm-分，ss-秒',
	'field_datetime_calendar'=>'开启公历',
	
	'field_datetime_color'=>'主题颜色',
	'field_datetime_grid'=>'格子主题',
	
	'field_datetime_min_max'=>'选择限定',
	'field_datetime_min_max_p'=>'日期可选择的范围，如-7,7表示可选择前后7天的时间，2018-9-10，2019-10-11表示可选择这2个日期范围内的日期，9:10:10,15:20:20表示可选择这2个时间范围内的时间',
		
	'field_datetime_date_type'=>'日期类型',
	'field_datetime_date_type_0'=>'日期',
	'field_datetime_date_type_1'=>'时间日期',
	'field_datetime_date_type_2'=>'年',
	'field_datetime_date_type_3'=>'年月',
	'field_datetime_date_type_4'=>'时间',
	
	'field_file_ext'=>'文件后缀',
	'field_file_ext_p'=>'允许上传的后缀文件，留空表示不限制，多个用英文竖线(|)隔开',
	'field_file_size'=>'文件大小',
	'field_file_size_p'=>'允许上传的单个文件的大小，单位为:KB，0或空表示不限制',
	'field_file_auto'=>'自动上传',
	'field_file_auto_p'=>'选择完成后是否自动上传',
	'field_file_domain'=>'显示域名',
	'field_file_domain_p'=>'在图片输出时，连接是否带上网站域名',
	'field_file_required'=>'是否必选',
	'field_file_server'=>'图库',
	'field_file_server_p'=>'开启可以直接从已上传的图库中选择图片，需安装[upload]插件',
	
	'field_editor'=>'编辑器',
	'field_editor_height'=>'编辑器高',
	
	'field_template_manager'=>'模版管理',
	'field_template_manager_p'=>'模版留空表示删除该模版，在[添加模版]项输入内容表示添加新模版',
	'field_template_add'=>'添加模版',
	'field_template_add_p'=>'在此项目里输入内容表示添加模版',
	'field_form_type_form'=>'表单类型',
	'field_form_type_sign'=>'表单标识',
	'field_form_type_install_module'=>'安装模块',
	
	'scheme'=>'模板方案',
	'scheme_sign_pc'=>'电脑方案',
	'scheme_sign_mobile'=>'手机方案',
	'scheme_title'=>'方案名称',
	'scheme_title_p'=>'为方便使用管理，建议使用汉字',
	'scheme_sign'=>'方案标识',
	'scheme_sign_p'=>'模板方案唯一标识，请用数字,字符串,_,数字等，请不要使用汉字',
	'scheme_exist_p'=>'方案标识存在，请重新填写',
	'scheme_js_css'=>'加载文件',
	'scheme_js_css_p'=>'如果该方案需要加载额外的样式文件或者JS文件，请填写对应的文件路径，每行一个，根路径为public/static/',
	'scheme_tem'=>'模板',
	'scheme_tem_set'=>'选择该模版',
	'scheme_tem_set_default'=>'设为默认模板',
	'scheme_tem_diy'=>'自定义认模板',
	'scheme_tem_diy_p'=>'请输入自定义模版的HTML代码',
	'scheme_tem_save'=>'保存成模版',
	
	
	'ensure_del'=>'数据删除后不可恢复！，你确定要删除吗？',
	
	'field_must_num'=>'必须为数字',
	'field_must_min'=>'不能小于{:min}',
	'field_must_max'=>'不能大于{:max}',
	'field_must_min_max'=>'必须大于{:min}小于{:max}',
	'field_must_min_len'=>'至少需要选择{:min_len}个选项',
	'field_must_max_len'=>'最多可选择{:max_len}个选项',
	'field_must_min_max_len'=>'至少需要选择{:min_len}个最多选择{:max_len}个选项',
	
	'field_must_min_len_str'=>'至少需要输入{:min_len}个字符',
	'field_must_max_len_str'=>'最多可输入{:max_len}个字符',
	'field_must_min_max_len_str'=>'至少需要{:min_len}个最多可输入{:max_len}个字符',
	
	'field_must_text'=>'请正确输入字段内容',
	'field_not_table'=>'没有获取到数据表',
	'field_not_only'=>'已存在,请重新填写',


];
