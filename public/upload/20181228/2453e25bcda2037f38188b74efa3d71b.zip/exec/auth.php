<?php
return [
      'auth_0'=>['title'=>'字段管理','type'=>'admin','order_num'=>0,'class'=>1],	  
	  'auth_0_0'=>['title'=>'表单类型列表','order_num'=>0,'parent_id'=>'auth_0','m'=>'field','c'=>'Form','a'=>'form_type_list'],
	  'auth_0_1'=>['title'=>'表单启用禁用','order_num'=>0,'parent_id'=>'auth_0','m'=>'field','c'=>'Form','a'=>'form_type_edit']
];
