<?php
namespace app\field\controller;
use user\Admin;
class Upload extends Admin
{
/*************************************************************
	scheme_list 方案列表
*************************************************************/	
    public function upload()
    {
		// 获取表单上传文件 例如上传了001.jpg
		if (isInstall('upload')) { 
			$config = getConfig("config.filesname","","upload");
			$path = exeFun("GetfilePath",["",$config],"upload");
		}else{
			$path  = "";
			if(session('admin.id')) $path = '/admin/'.session('admin.id').'/';
			if(session('member.id')) $path = '/member/'.session('member.id').'/';
			$path = 'upload'.$path;	
		}	
		$file = request()->file();
		$return = [];
		foreach($file as $val){
			$info = $val->rule('uniqid')->move($path);
			if($info){
				$fullName = str_replace('\\', '/' , $info->getSaveName()); // zesz
				$return = ['code'=>0,'msg'=>'上传成功','data'=>['src'=>request()->rootUrl().'/'.$path.$fullName]];
			}else{
				$return = ['code'=>1,'msg'=>$files->getError()];
			}			
		}
		// 移动到框架应用根目录/uploads/ 目录下
		return $return;
    }
	
}
