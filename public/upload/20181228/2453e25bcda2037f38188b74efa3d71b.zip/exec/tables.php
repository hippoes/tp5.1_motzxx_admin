<?php 
return [
  0 => 'field_form_type',
  1 => 'field_scheme',
  2 => 'field_table',
];