<?php
namespace app\field\controller;
use form\Form;
class Input extends Form
{

/*************************************************************
	form_list 列表
*************************************************************/	
    public function form_list()
    {
			$table = $this->request->param('table');
	
			if($this->request -> isAjax() || $this->request-> isPost())
			{
					$page = $this->request->param('page/d',1);
					$limit = $this->request->param('limit/d',20);
					
					$totalCount = db($table)-> count();
					$info = db($table) ->  page($page,$limit) -> order(['id'=>'asc']) -> select();
					
					$data['code'] = 0;
					$data['data'] = $info;
					$data['count'] = $totalCount;
					$data['msg'] = lang('not_data');
					
					return $data;
	
			}
			else
			{
					return $this->fetch();
					
			}
    }	
/*************************************************************
	form_add 添加
*************************************************************/	
    public function form_add()
    {
			$table = $this->request->param('table');

			$sign = $this->request->param('sign','');

			if($this->request -> isAjax() || $this->request-> isPost())
			{
				    $return = formSave();
					return $return;
			}
			else
			{
					return $this->fetch();
					
			}
    }	
	
/*************************************************************
	form_edit 编辑
*************************************************************/	
    public function form_edit()
    {
			$table = $this->request->param('table');
	        $id = $this->request->param('id/d',0);
			$sign = $this->request->param('sign','');
			if($this->request -> isAjax() || $this->request-> isPost())
			{
				    $return = formSave($id);
					return $return;
			}
			else
			{
					return $this->fetch();
			}
    }
}



