<?php
/*************************************************************
	fieldAdd 添加字段
	@param   fieldInfo array  要判断的字段名称
    @return int
*************************************************************/	
$this -> fieldAdd=function($fieldInfo){

	   $field_info=[];
	   
	   if(count($fieldInfo) <=0) return 0;
	   
	   $field = isset($fieldInfo['field']) && $fieldInfo['field'] ? $fieldInfo['field'] : NULL;
	   $table = isset($fieldInfo['table']) && $fieldInfo['table'] ? $fieldInfo['table'] : NULL;
	   
	   $formType = isset($fieldInfo['form_type']) && $fieldInfo['form_type'] ? $fieldInfo['form_type'] : NULL;
	   
	   $is_num = isset($fieldInfo['property']['is_num']) && $fieldInfo['property']['is_num'] ? $fieldInfo['property']['is_num'] : 0;
	   $min = isset($fieldInfo['property']['min']) && $fieldInfo['property']['min'] ? $fieldInfo['property']['min'] : 0;
	   $decimal_num = isset($fieldInfo['property']['decimal_num']) && $fieldInfo['property']['decimal_num'] ? $fieldInfo['property']['decimal_num'] : 0;
	   $default = isset($fieldInfo['property']['default']) && $fieldInfo['property']['default'] ? $fieldInfo['property']['default'] : "";
	   
	   $min_len = isset($fieldInfo['property']['min_len']) && $fieldInfo['property']['min_len'] ? $fieldInfo['property']['min_len'] : 0;
	   
	   $describe = isset($fieldInfo['describe']) && $fieldInfo['describe'] ? $fieldInfo['describe'] : "";
	   
	   if(!$field || !$table || !$formType) return 0;
	   
	   try{
				
				$field_info['field'] = $field;
				$field_info['table'] = $table;
				$field_info['default'] = $default;
				$field_info['comment'] = $describe;
				$field_info['is_null'] = 1;
				$field_info['type'] = "varchar";
				
				$Field = new \database\Field();
                $create = $Field -> field_create($field_info);
				return $create==1 ? 1 : 0;
		}catch(\Exception $e){
			   return 0;
		}
	
};

/*************************************************************
	fieldEdit 添加字段
	@param   fieldInfo array  要判断的字段名称
    @return int
*************************************************************/	
$this -> fieldEdit=function($fieldInfo){

	   $field_info=[];
	   
	   if(count($fieldInfo) <=0) return 0;
	   
	   $field = isset($fieldInfo['field']) && $fieldInfo['field'] ? $fieldInfo['field'] : NULL;
	   $table = isset($fieldInfo['table']) && $fieldInfo['table'] ? $fieldInfo['table'] : NULL;
	   
	   $formType = isset($fieldInfo['form_type']) && $fieldInfo['form_type'] ? $fieldInfo['form_type'] : NULL;
	   
	   $is_num = isset($fieldInfo['property']['is_num']) && $fieldInfo['property']['is_num'] ? $fieldInfo['property']['is_num'] : 0;
	   $min = isset($fieldInfo['property']['min']) && $fieldInfo['property']['min'] ? $fieldInfo['property']['min'] : 0;
	   $decimal_num = isset($fieldInfo['property']['decimal_num']) && $fieldInfo['property']['decimal_num'] ? $fieldInfo['property']['decimal_num'] : 0;
	   $default = isset($fieldInfo['property']['default']) && $fieldInfo['property']['default'] ? $fieldInfo['property']['default'] : "";
	   
	   $min_len = isset($fieldInfo['property']['min_len']) && $fieldInfo['property']['min_len'] ? $fieldInfo['property']['min_len'] : 0;
	   
	   $describe = isset($fieldInfo['describe']) && $fieldInfo['describe'] ? $fieldInfo['describe'] : "";
	   
	   if(!$field || !$table || !$formType) return 0;
	   
	   try{
				
				$field_info['field'] = $field;
				$field_info['table'] = $table;
				$field_info['default'] = $default;
				$field_info['comment'] = $describe;
				$field_info['is_null'] = 1;
                $field_info['type'] = "varchar";
				
				$Field = new \database\Field();
                $edit = $Field -> field_edit($field_info);
				return $edit==1 ? 1 : 0;
		}catch(\Exception $e){
			   return 0;
		}
	
};	


/*************************************************************
	fieldDel 删除字段
	@param   fieldInfo array  要判断的字段名称
    @return int
*************************************************************/	
$this -> fieldDel=function($fieldInfo){

	   $field_info=[];

	   if(count($fieldInfo) <=0) return 0;
	   
	   $field = isset($fieldInfo['field']) && $fieldInfo['field'] ? $fieldInfo['field'] : NULL;
	   $table = isset($fieldInfo['table']) && $fieldInfo['table'] ? $fieldInfo['table'] : NULL;
	   
	   if(!$field || !$table) return 0;
	   
	   try{
				
				$field_info['field'] = $field;
				$field_info['table'] = $table;

				$Field = new \database\Field();
                $del = $Field -> field_del($field_info);
				return $del==1 ? 1 : 0;
		}catch(\Exception $e){
			   return 0;
		}
	
};	

/*************************************************************
	showForm 构建表单，获取到数据转换成表单能识别的数据
	@param   temStr string  模版字符串
	@param   field array  字段信息
	@param   record array  记录信息
    @return int
*************************************************************/	
$this -> showForm=function($temStr,$field=NULL,$record=NULL){

	   if(!$temStr || !$field) return "";

	   $default = $field['property']['default'];
	   $default = trim($default) ? explode(",", $default) : [];

	   $optionsStr = isset($field['property']['options']) ? $field['property']['options'] : "";
	   $optionsStr = str_replace(["\r\n", "\r"], "\n", $optionsStr);
	   $options = explode("\n", $optionsStr);
	   
	   $optionString = "";
	   $text = $optionValue = "";
	   foreach($options as $option)
	   {

			   $optionArray = explode("=", $option);
			   
			   if(count($optionArray) ==1 && isset($optionArray[0]) )
			   {
					 $text = $optionValue = $optionArray[0];
			   }
			   else if(count($optionArray) > 1 && isset($optionArray[1]))
			   {
					 $text  =  $optionArray[0];
					 $optionValue = $optionArray[1];
			   }

			   if(in_array($optionValue,$default))
			   {
				   $optionString=$optionString."<input type='checkbox' name='[field][]' title='".$text."' class='[css]' [form_property] value='".$optionValue."' lay-text='".$text."' checked>&nbsp;&nbsp;";
			   }
			   else
			   {
				   $optionString=$optionString."<input type='checkbox' name='[field][]' title='".$text."' class='[css]' value='".$optionValue."' lay-text='".$text."' [form_property]>&nbsp;&nbsp;";
			   }

	   }
	   
	   $temStr = preg_replace("/\[options\]/i",$optionString,$temStr);

	   return $temStr;	
};
/*************************************************************
	saveForm 保存表单时，拿到提交的post数据转换成保存到数据表中的数据
	@param   value string|array  要转换的数据
	@param   post array  表单提交的所有数据
    @return int
*************************************************************/	
$this -> saveForm=function($value,$post=[]){

	   if(is_array($value))
	   {
		   $return = implode(",", $value);
		   return $return;
	   }
	   else
	   {
		   return trim($value);
	   }
};					
?>