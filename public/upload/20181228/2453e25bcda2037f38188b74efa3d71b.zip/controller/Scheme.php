<?php
namespace app\field\controller;
use user\Admin;
class Scheme extends Admin
{
/*************************************************************
	scheme_list 方案列表
*************************************************************/	
    public function scheme_list()
    {
		$page = $this->request->param('page/d',1);
		$limit = $this->request->param('limit/d',20);
		$table = $this->request->param('table','');
		$keyword = $this->request->param('keyword','','trim');
		$where=NULL;
		
		if(!$table) $this->error(lang('err_param'));
		
		if($keyword)
		{
			$where = $keyword ? " (`title` LIKE '%".$keyword."%' or `sign`='".$keyword."') AND `table`='".$table."' " : '1=1';
		}
		else
		{
			$where[] = ['table','=',$table]; 
		}

		$totalCount = db('field_scheme')->where($where)-> count();
		$info = db('field_scheme')->where($where) -> page($page,$limit) -> order(['id'=>'asc']) -> select ();
		
		$data['code'] = 0;
		$data['data'] = $info;
		$data['count'] = $totalCount;
		$data['msg'] = lang('not_data');
		
		if($this->request -> isAjax())
		{
			    return $data;
		}
		else
		{
			    $this->assign('table',$table);
				return $this->fetch();
		}
    }
	
/*************************************************************
	scheme_add 方案添加
*************************************************************/	
    public function scheme_add()
    {

		$table = $this->request->param('table',"",'trim');

		if($this->request -> isAjax() || $this->request-> isPost())
		{
			    $param = $this->request->param();

				if(!$table)
				{
				    	$data= ['err'=>1,'content'=>lang('err_param')];
			            return $data;
				}
				
				$only =  valueOnly('sign',trim($param['sign']),"field_scheme");
				
				if($only)
				{
				    	$data= ['err'=>1,'content'=>lang('scheme_exist_p')];
			            return $data;
				}

                $param = array_del_key($param,['id']);
				$insert = db('field_scheme') ->strict(false)->insert($param);
				
				if($insert)
				{  
					  $data= ['err'=>0,'content'=>lang('op_success')];
				}
				else
				{
					  $data= ['err'=>1,'content'=>lang('err_param')];
				}
				
				return  json($data);
		}
		else
		{
			    if(!$table) $this->error(lang('err_param'));
				$this->assign('table',$table);
			    
                return $this->fetch();
		}
		
    }
	
/*************************************************************
	scheme_edit 方案编辑
*************************************************************/	
    public function scheme_edit()
    {
		$id = $this->request->param('id');

		if($this->request -> isAjax() || $this->request-> isPost())
		{
			    $param =$fieldParam= $this->request->param();
				if(!$id)
				{
				    	$data= ['err'=>1,'content'=>lang('err_param')];
			            return $data;
				}
				
				
                $param = array_del_key($param,['id','sign']);
                $updateWhere[] = ['id','in',$id];
                
				$update = db('field_scheme')->where($updateWhere) ->strict(false)->update($param);
				
				if($update!==false) return json(['err'=>0,'content'=>lang('op_success')]);
				
				$data= ['err'=>1,'content'=>lang('err_fail')];
				return  json($data);

		}
		else
		{
			    if(!$id) $this->error(lang('err_param'));
                
				$infoWhere[] = ['id','in',$id];
				$info = db('field_scheme')->where($infoWhere)->find();
				
				if(!$info) $this->error(lang('err_info'));
				
				$this->assign('info',$info);

			    return $this->fetch();
                
		}
    }
	
/*************************************************************
	scheme_del 方案删除
*************************************************************/	
    public function scheme_del()
    {
		$id = $this->request->param('id','','trim');

		if(!$id)
		{
			 $data= ['err'=>1,'content'=>lang('err_param')];
			 return $data;
		}

		$where[] = ['id','in',$id];
		$where[] = ['isdel','<>',1];
		
		if($this->request-> isPost() || $this->request-> isAjax())
		{
			  $info = db('field_scheme') -> where($where) -> select();	
			  $delNum = 0 ; 

			  foreach($info as $v)
			  {
				    $delWhere =[['id','=',$v['id']]];
				    $del = db('field_scheme')->where($delWhere)->delete();
					if($del) $delNum++;
			  }
			  
			  if($delNum > 0 )
			  { 
				   $data= ['err'=>0];
				   return $data;
			  }
			  else
			  {
				   $data= ['err'=>1,'content'=>lang('err_fail')];
				   return $data;
			  }			
		}
		else
		{
			  return $data= ['err'=>0];
		}
    }
	
/*************************************************************
	scheme_tem 方案模板
*************************************************************/	
    public function scheme_tem()
    {
		$id = $this->request->param('id');
		$type = $this->request->param('type','pc');

		if($this->request -> isAjax() || $this->request-> isPost())
		{
			    $param =$fieldParam= $this->request->param();
				if(!$id)
				{
				    	$data= ['err'=>1,'content'=>lang('err_param')];
			            return $data;
				}
				
				$fields=isset($param['fields']) ? $param['fields'] : NULL;

				$data = [];
				$tem = [];
				if($fields)
				{
					  foreach($fields as $k=>$v)
					  {
				           if($v=="diy")
						   {
							    $tem[$k] =['diy'=>($param[$k."_diy"])];
						   }
						   else
						   {
							    $tem[$k] =[$v=>($param[$k."_diy"])];
						   }
						  
					  }
				}
				
				if(count($tem) > 0 )  $data['tem_'.$type] = $tem;

				$infoWhere[] = ['id','in',$id];
				
				$update = db('field_scheme')->where($infoWhere)->json(['tem_'.$type])->update($data);
				
				$temStr = $this->display(getForm($id,NULL,$type));
				if($update!==false) return json(['err'=>0,'content'=>lang('op_success'),'temStr'=>$temStr]);
				
				$data= ['err'=>1,'content'=>lang('err_fail')];
				return  json($data);

		}
		else
		{
			    if(!$id) $this->error(lang('err_param'));
                
				$infoWhere[] = ['id','in',$id];
				$info = db('field_scheme')->where($infoWhere)->json(['tem_pc','tem_mobile'])->find();
               
				if(!$info) $this->error(lang('err_info'));
				
				$fields = getFields($info['table']);
				
				$jsCss = getJsCss($info['js_css']);
				
				$temStr = $this->display(getForm($id,NULL,$type));
				
				$fieldJs = getFieldJs(0);
				
				$fieldJs = $this->display($fieldJs);
				
				$this->assign('field_js',$fieldJs);
				$this->assign('jsCss',$jsCss);
				$this->assign('type',$type);
				
				$this->assign('info',$info);
				$this->assign('tem',$info['tem_'.$type]);
				$this->assign('temStr',$temStr);
				$this->assign('fields',$fields);

			    return $this->fetch();
                
		}

    }
	
/*************************************************************
	scheme_tem_add 方案模板
*************************************************************/	
/*    public function scheme_tem_add()
    {
		$tem = $_POST['tem'];
		$field = $this->request->param('field','','trim');
		$table = $this->request->param('table','','trim');
		$type = $this->request->param('type','','trim');
		$type = $type ? $type : "pc";
		if(!$tem || !$field || !$table) return ['err'=>1];
		
		$where[]=['field','=',$field];
		$where[]=['table','=',$table];
		$fieldInfo = getFieldInfo($where);
		
		$temPath = getFieldTemPath($fieldInfo['form_type']).$type.DIRECTORY_SEPARATOR;

        
    }*/
	
}
