<?php
namespace app\field\controller;
use user\Admin;
class Form extends Admin
{
/*************************************************************
	form_type_list 字段模版
*************************************************************/	
    public function form_type_list()
    {
		    $page = $this->request->param('page/d',1);
			$limit = $this->request->param('limit/d',20);
			
			$totalCount = db('field_form_type')-> count();
			$info = db('field_form_type') ->  page($page,$limit) -> order(['order_num','id'=>'asc']) -> select();
			
			$data['code'] = 0;
			$data['data'] = $info;
			$data['count'] = $totalCount;
			$data['msg'] = lang('not_data');
			
			if($this->request -> isAjax())
			{
					return $data;
			}
			else
			{
				    $this->assign('data',$data);
					return $this->fetch();
			}
    }
/*************************************************************
	form_type_edit 表单类型编辑
*************************************************************/	
    public function form_type_edit()
    {
		$id = $this->request->param('id');

		if($this->request -> isAjax() || $this->request-> isPost())
		{
			    $param =$this->request->param();

				if(!$id)
				{
				    	$data= ['err'=>1,'content'=>lang('err_param')];
			            return $data;
				}

				if(!isset($param['batch']) &&  !isset($param['status'])) $param['status'] = 0;
                $param = array_del_key($param,['id']);
                $updateWhere[] = ['id','in',$id];
				$update = db('field_form_type')->where($updateWhere) ->strict(false)->update($param);
				
				if($update!==false)
				{
					$data = ['err'=>0,'content'=>lang('op_success')];
				} 
				else
				{
					$data= ['err'=>1,'content'=>lang('err_fail')];
				}
				return  json($data);

		}
		else
		{
			    if(!$id) $this->error(lang('err_param'));
                $infoWhere[] = ['id','=',$id];
                $info = db('field_form_type') -> where($infoWhere) -> find();

				if(!$info) $this->error(lang('err_info'));
				$this->assign('info',$info);
				$this->assign('id',$id);

				return $this->fetch();
                
		}
    }
	
/*************************************************************
	form_type_edit 表单类型编辑
*************************************************************/	
    public function field_template_list()
    {
		    $id = $this->request->param('id/d',0);
            if(!$id) $this->error(lang('err_param'));
			
			$infoWhere[] = ['id','=',$id];
            $info = db('field_form_type') -> where($infoWhere) -> find();
			
			if(!$info) $this->error(lang('err_info'));
			
			$fieldJs = getFieldJs();
            $pc = getFieldTemArray($info['sign'],"pc");
			$mobile = getFieldTemArray($info['sign'],"mobile");
			
			$this->assign('field_js',$fieldJs);
			$this->assign('info',$info);
			$this->assign('pc',$pc);
			$this->assign('mobile',$mobile);

			return $this->fetch();
    }	
	
/*************************************************************
	form_type_set_default 设置表单默认模版
*************************************************************/	
    public function form_type_set_default()
    {
		    $param = $this->request->param();
            if(!$param['form_type'] || (!isset($param['default_pc']) && !isset($param['default_mobile'])) ) $this->error(lang('err_param'));
			
			$updateWhere[] = ['sign','=',$param['form_type']];
			
			$data=[];
			
			if(isset($param['default_pc']))
			{
				$data['default_pc'] = $param['default_pc'];
			}  
			else
			{
				$data['default_mobile'] = $param['default_mobile'];
			}

            $update = db('field_form_type')->where($updateWhere) ->strict(false)->update($data);
			
			if($update!==false)
			{
				$data = ['err'=>0,'content'=>lang('op_success')];
			} 
			else
			{
				$data= ['err'=>1,'content'=>lang('err_fail')];
			}
			return $data;
    }	
	
/*************************************************************
	form_type_set_template 设置表单模版
*************************************************************/	
    public function form_type_set_template()
    {
		    $param = $this->request->param();
			$formType = $param['form_type'];
			if(!$formType) $this->error(lang('err_param'));
			$F = new \files\File();
			if(isset($param['pc']))
			{
				  $temPath =getFieldTemPath($formType,0)."templet".DIRECTORY_SEPARATOR."pc".DIRECTORY_SEPARATOR;
				  foreach($param['pc'] as $key => $value)
				  {
					    if(!trim($value) && $key!="add")
						{
							  
							  $F->f_delete($temPath.$key.".html");
						}
						else
						{
							 if($key!="add")
							 {
								   $F->write($temPath.$key.".html",htmlspecialchars_decode($value));
							 }
							 else if($key=="add" && trim($value))
							 {
								   $F->write($temPath.time().".html",htmlspecialchars_decode($value));
							 }
						}
						
				  }
			}
			
			if(isset($param['mobile']))
			{
				  $temPath =getFieldTemPath($formType,0)."templet".DIRECTORY_SEPARATOR."mobile".DIRECTORY_SEPARATOR;
				  foreach($param['mobile'] as $key => $value)
				  {
					   	if(!trim($value) && $key!="add")
						{
							  $F->f_delete($temPath.$key.".html");
						}
						else
						{
							 if($key!="add")
							 {
								   $F->write($temPath.$key.".html",htmlspecialchars_decode($value));
							 }
							 else if($key=="add" && trim($value))
							 {
								   $F->write($temPath.time().".html",htmlspecialchars_decode($value));
							 }
						}
				  }
			}
			
			$data = ['err'=>0,'content'=>lang('op_success')];
			return json($data);
    }
}



