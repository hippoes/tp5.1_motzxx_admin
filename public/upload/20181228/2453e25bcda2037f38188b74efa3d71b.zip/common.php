<?php 
/*************************************************************
	getFormType 获取表单类型
    @return array
*************************************************************/	
	function getFormType()
    {
		 $where[] = ['status','=',1];
		 $info =  db('field_form_type')->where($where)-> order(['order_num','id'=>'asc']) ->column('title','sign');
		 return $info ? $info : [];
    }
/*************************************************************
	getFormTypeInfo 获取表单单个类型
	@param   table string  数据表的名称
    @return int
*************************************************************/	
	function getFormTypeInfo($formType="text")
    {
		$where[] = ['sign','=',$formType];
		$info =  db('field_form_type')->where($where)-> find();
		return $info ? $info : [];
    }	
/*************************************************************
	getFieldTemPath 获取字段路径
	@param   formType string  表单类型
	@param   type int  是否获取默认路径 1获取 0不获取
    @return array
*************************************************************/	
	function getFieldTemPath($formType="text",$type=1)
    {
		 $where[] = ['sign','=',$formType];
		 $info =  db('field_form_type')->where($where)-> find();
		 
		 $install_module = $info['install_module'] ? $info['install_module'] : "field";
		 
		 $path = env('app_path').$install_module.DIRECTORY_SEPARATOR."field_tem".DIRECTORY_SEPARATOR.$formType.DIRECTORY_SEPARATOR;
		 
		 $F = new \files\File();
		 
		 if($type && !$F -> d_has($path) ) $path = env('app_path')."field".DIRECTORY_SEPARATOR."field_tem".DIRECTORY_SEPARATOR."text".DIRECTORY_SEPARATOR;
		 return $path;
    }
	
/*************************************************************
	getFieldTemPath 获取字段对应的表单模板数组
	@param   formType string  表单类型
	@param   type string  pc:电脑模板，mobile：手机模板
    @return array
*************************************************************/	
	function getFieldTemArray($formType="text",$type="pc")
    {
		 $path = getFieldTemPath($formType);
		 $pathTem = $path."templet".DIRECTORY_SEPARATOR.$type.DIRECTORY_SEPARATOR;
		 $dir= scandir($pathTem);

         $F = new \files\File();
		 $returnData = [];
		 foreach($dir as $v)
		 {
			   if($v!="." && $v!="..")
			   {
				  $pathInfo = explode(".", $v);
				  if(isset($pathInfo[0]) && $pathInfo[0])
				  {
					   $returnData[$pathInfo[0]] = $F->read($pathTem.$v);
				  }
				  
			   }
		 }
		 
		 return $returnData;
    }
	
		
/*************************************************************
	getFieldDescribe 获取表单字段标签描述
	@param   table string  数据表的名称
    @return int
*************************************************************/	
	function getTemDescribe($formType="text")
    {
		$path = getFieldTemPath($formType);
		$F = new \files\File();
		return $F->read($path."tem_describe.html");
    }
	
/*************************************************************
	getFieldLable 获取字段标签按钮
	@param   formType string  表单类型
	@param   input string  插入的表单对象
    @return string
*************************************************************/	
	function getFieldLable ($formType='text',$input="")
    {
		$temPath = getFieldTemPath($formType);
		$fieldConfig = FF('config',NULL,$temPath);
		
		
		$fieldConfigDefault=[
				 'field'=>['title'=>lang('field_name'),'default'=>'','describe'=>lang('field_name_p')],
				 'title'=>['title'=>lang('field_title'),'default'=>'','describe'=>lang('field_title_p')],
				 'sort'=>['title'=>lang('sort'),'default'=>0,'describe'=>lang('field_sort_p')],
				 'group'=>['title'=>lang('field_group'),'default'=>"base",'describe'=>lang('field_group_p')],
				 'describe'=>['title'=>lang('field_describe'),'default'=>"",'describe'=>lang('field_describe')]
		];
		
		$fieldConfig = array_merge($fieldConfigDefault,$fieldConfig);
		$returnData = "";
		foreach($fieldConfig as $key=>$value)
		{
			  $returnData=$returnData."<div class='layui-btn  layui-btn-primary layui-btn-sm lable_button' data-value='[".$key."]' data-input='".$input."' data-title='".$value['describe']."'>".$value['title']."</div>";
		}
		
		return "<div class='layui-btn-group'>".$returnData."</div>";
    }
/*************************************************************
	getFieldInfo 获取字段信息
	@param   param int|string|array  如果为  数字：id，字符串：field，数组：where
    @return array
*************************************************************/	
	function getFieldInfo($param=0)
    {
		  if(is_numeric($param))
		  {
			  $infoWhere[]= ['id','=',$param];
		  }
		  else if(is_string($param))
		  { 
			  $infoWhere[]= ['field','=',$param];
		  }
		  else if(is_array($param))
		  {
			  $infoWhere= $param;
		  }
		  
		  if(!isset($param['property']))
		  {
			  $info = db('field_table')->where($infoWhere)->json(['property','administrator_auth','member_auth'])->find();
		  }
		  else
		  {
			  $info = $param;
		  }
		  
		  
		  $temPath = getFieldTemPath($info['form_type']);
		  $fieldConfig = FF('config',NULL,$temPath);
		  
		  if($fieldConfig)
		  {
			    foreach($fieldConfig as $key=>$value)
				{
					  if(!isset($info['property'][$key]))
					  {
						   if(isset($value['default']) )
						   {
							   $info['property'][$key] = $value['default'];
						   } 
						   else
						   {
							   $info['property'][$key]="";
						   }
					  }
				}
		  }
		  
		  if(!isset($info['administrator_auth']['add'])) $info['administrator_auth']['add'] = [];
		  if(!isset($info['administrator_auth']['edit'])) $info['administrator_auth']['edit'] = [];
		  if(!isset($info['administrator_auth']['show'])) $info['administrator_auth']['show'] = [];
		  
		  if(!isset($info['member_auth']['add'])) $info['member_auth']['add'] = [];
		  if(!isset($info['member_auth']['edit'])) $info['member_auth']['edit'] = [];
		  if(!isset($info['member_auth']['show'])) $info['member_auth']['show'] = [];
		  
		  if(!isset($info['property']['is_num'])) $info['property']['is_num'] = 0;
		  if(!isset($info['property']['only'])) $info['property']['only'] = 0;
		  if(!isset($info['status'])) $info['status'] = 0;
		  if(!isset($info['property']['min_len'])) $info['property']['min_len'] = 0;
		  if(!isset($info['property']['max_len'])) $info['property']['max_len'] = 0;
		  if(isset($info['property']['server']) &&  $info['property']['server'] && isInstall('upload') ) 
		  {
			  $info['property']['server'] = 1;
		  }
		  else
		  {
			  $info['property']['server'] = 0;
		  }
		  
		  if($info['property']['is_num'] && trim($info['property']['default']) && !is_numeric(trim($info['property']['default']))) $info['property']['default'] = 0;
		  
		  return $info;
    }
/*************************************************************
	getFields 获取表字段
	@param   table string  数据表名称
	@param   tem int  1:有模板信息，0:没模板信息
    @return array
*************************************************************/	
	function getFields($table,$tem=['pc','mobile'])
    {
		 $infoWhere[]= ['table','=',$table];
		 $infoWhere[]= ['status','=',1];
		 $info = db('field_table')->where($infoWhere)->json(['property','administrator_auth','member_auth'])-> order(['order_num','id'=>'asc'])->select();
		 
		 $returnData=[];
		 $L = new \label\Label();
		 foreach($info as $k=>$v)
		 {
			  $field= getFieldInfo($v);
			  if($tem)
			  {
				   foreach($tem as $temType)
				   {
					   $field['tem_'.$temType] = getFieldTemArray($field['form_type'],$temType);
					   
					   foreach($field['tem_'.$temType] as $key=>$f_tem)
					   {
						    if($f_tem)
							{
								    $formType = $v['form_type'];
								    $getFormClass = new getForm($formType);
									if(isset($getFormClass->showForm) && $getFormClass->showForm) 
									{
										$f_tem = call_user_func_array($getFormClass->showForm,[$f_tem,$v]);
									}
								    $field['tem_'.$temType][$key] = $L->replace_field_label($f_tem,$v);
						    } 
					   }
				   }
				   
			  }
			  $returnData[] = $field;
		 }
		 
		 return $returnData;
    }
/*************************************************************
	fieldOnly 判断某个字段名称是否唯一
	@param   field string  要判断的字段名称
	@param   table string   判断字段所在的数据表
    @return int
*************************************************************/	
	function fieldOnly($field,$table)
    {
		 $Field = new \database\Field();
		 $is = $Field->has($field,$table);
         return $is ? 1 : 0;
    }

/*************************************************************
	fieldValueOnly 判断字段是否存在，包括数据表中的字段和字段记录中
	@param   fieldName string  字段名称
	@param   table string   判断字段所在的数据表
	@param   id string|array   该id的记录除外
    @return int
*************************************************************/	
	function fieldValueOnly($fieldName,$table,$id=NULL)
    {
		 if(!$table || !$fieldName) return 0;

		 $where[]=['field','=',$fieldName];
		 $where[]=['table','=',$table];
		 if($id) $where[] = ['id','NOT IN',$id];
		 
		 $info = db('field_table')->field('field')->where($where)->find();
		 if(is_array($info) && count($info)>0) return 1;
		 
		 $fieldOnly = fieldOnly($fieldName,$table);
		 if($fieldOnly) return 1;
		 return 0;
    }
	
/*************************************************************
	valueOnly 判断某个值是否存在
	@param   fieldName string  字段名称
	@param   value string   字段的值
	@param   table string   判断字段所在的数据表
	@param   id string|array   该id的记录除外
    @return int
*************************************************************/	
	function valueOnly($fieldName,$value,$table,$id=NULL)
    {
		 if(!$table || !$fieldName) return 0;
		 
		 $where[]=[$fieldName,'=',$value];
		 if($id) $where[] = ['id','NOT IN',$id];
		 
		 $info = db($table)->field($fieldName)->where($where)->find();
		 if(is_array($info) && count($info)>0) return 1;
		 return 0;
    }
	
/*************************************************************
	tableToField 根据数据表的字段生成字段信息
	@param   table string  数据表的名称
    @return int
*************************************************************/	
	function tableToField($table)
    {
		 if(!$table) return 0;
		 
		 $F = new \database\Field();
		 $field_array=$F->get_field($table);
		 
		 //dump($field_array);
    }
	
	
/*************************************************************
	getJsCss 获取js css 文件
	@param   jsCss string  转换的数据
    @return string
*************************************************************/	
	function getJsCss($jsCss="")
    {
		 if(!$jsCss) return "";
		 $jsCss = str_replace(["\r\n", "\r"], "\n", $jsCss);
		 $jsCss = explode("\n", trim($jsCss));	
		 
		 $returnData ="";
		 foreach( $jsCss as $v)
		 {
			  $pathinfo  =pathinfo($v);
			  
			  switch (strtolower($pathinfo['extension']))
			  {
				case "js":
				  $returnData = $returnData.'<script type="text/javascript" src="'.getRoot().'public/static/'.$v.'"></script>'.PHP_EOL;
				  break;  
				case "css":
				  $returnData = $returnData.'<link rel="stylesheet" type="text/css" href="'.getRoot().'public/static/'.$v.'">'.PHP_EOL;
				  break;
				  break;
				default:
				  $returnData = $returnData.'<link rel="stylesheet" type="text/css" href="'.getRoot().'public/static/'.$v.'">'.PHP_EOL;
			  }
	     }
		 return $returnData;
    }
	
/*************************************************************
	getFieldJs 获取字段中js代码文件
	@param   script int  是否需要 script标签 1需要0不需要
    @return string
*************************************************************/	
	function getFieldJs($script =1)
    {
		 $formType= getFormType();
		 $js="";
		 foreach($formType as $k => $v)
		 {
			    $path = getFieldTemPath($k);
				$F = new \files\File();
				$txt=$F->read($path."field.js");
				if(trim($txt))
				{
					$js = $js.PHP_EOL.trim($txt).PHP_EOL;
				}
				
		 }
		 
		 return $script ? "<script>".PHP_EOL.$js.PHP_EOL."</script>" : $js;
    }
	
/*************************************************************
	getSchemeInfo 获取方案信息
	@param   param int|string|array  如果为  数字：id，字符串：field，数组：where
    @return string
*************************************************************/	
	function getSchemeInfo($param=0)
    {
		  if(!$param) return [];
		  if(is_numeric($param))
		  {
			  $infoWhere[]= ['id','=',$param];
		  }
		  else if(is_string($param))
		  { 
			  $infoWhere[]= ['sign','=',$param];
		  }
		  else if(is_array($param))
		  {
			  $infoWhere= $param;
		  }
		  
		  $info = db('field_scheme')->where($infoWhere)->json(['tem_pc','tem_mobile'])->find();
		  
		  return $info ? $info : [];
    }		
/*************************************************************
	getForm 替换字符串中对应的值
	@param   param int|string|array  如果为  数字：id，字符串：field，数组：where
	@param   type string  生成表单类型，pc为电脑，mobile为手机
	@param   record array  表单对应的记录信息
    @return int
*************************************************************/	

	function getForm($param=0,$record=[],$type='pc')
    {
		  $info = getSchemeInfo($param);
		  $returnData="";

		  if(!$info) return "";
		  switch ($type)
		  {
			case "pc":
			  $tem = $info['tem_pc'];
			  break;  
			case "mobile":
			  $tem = $info['tem_mobile'];
			  break;
			default:
			  $tem = $info['tem_pc'];
		  }
		 
		  $F = new \files\File();
		  $L = new \label\Label();

		  $table = $info['table'];
		  
		  $fieldWhere[]= ['table','=',$table];
		  $fieldWhere[]= ['status','=',1];
		  $fieldInfo = db('field_table')->where($fieldWhere)->json(['property','administrator_auth','member_auth'])-> order(['order_num','id'=>'asc'])->select();

		  foreach($fieldInfo as $key=>$val)
		  {

				$field= getFieldInfo($val);
				$fieldName =$field['field'];
				$formType = $field['form_type'];

                if($record && is_array($record) && count($record) > 0 )
				{
					  $field['property']['default'] = isset($record[$fieldName]) ? $record[$fieldName] : ($field['property']['is_num'] ? 0 : "" );
				}
				else
				{
					  $field['property']['default'] = isset($field['property']['default']) ? $field['property']['default'] : ($field['property']['is_num'] ? 0 : "");
				}
				
				$temInfo = isset($tem[$fieldName]) ? $tem[$fieldName] : NULL;
				
				if($temInfo)
				{
					 $temFileName = key($temInfo); 
					 $temStr =$temInfo[$temFileName];

					 if($temFileName !="diy")
					 {
						  $temPath = getFieldTemPath($formType)."templet".DIRECTORY_SEPARATOR.$type.DIRECTORY_SEPARATOR.$temFileName.".html";
						  
						  $formTypeInfo = getFormTypeInfo($formType);
						  
						  if(!$F->f_has($temPath)) $temPath = getFieldTemPath($formType)."templet".DIRECTORY_SEPARATOR.$type.DIRECTORY_SEPARATOR.$formTypeInfo['default_'.$type].".html";
						  $temStr = $F->read($temPath);
					 } 
				}
				else
				{
					 $formTypeInfo = getFormTypeInfo($formType);
					 $temPath = getFieldTemPath($formType)."templet".DIRECTORY_SEPARATOR.$type.DIRECTORY_SEPARATOR.$formTypeInfo['default_'.$type].".html";
					 $temStr = $F->read($temPath);
				}
				
			    $getFormClass = new getForm($formType);

				if(isset($getFormClass->showForm) && $getFormClass->showForm) 
				{
					$temStr = call_user_func_array($getFormClass->showForm,[$temStr,$val,$record]);
				}
		
			    $returnData = $returnData.$L->replace_field_label($temStr,$field);
		   }
		        return $returnData; 
    }
	
/*************************************************************
	form 替换字符串中对应的值
	@param   param int|string|array  如果为  数字：id，字符串：field，数组：where
	@param   type string  生成表单类型，pc为电脑，mobile为手机
	@param   id int  表单对应的记录信息id
    @return int
*************************************************************/	

	function form($param=0,$id=[],$type='pc',$group=NULL)
    {
		
		  $record = [];
		  $getJsCss="";
		  $tem="";
	      $info = getSchemeInfo($param);
		  $groupStr=[];

		  $userInfo = isset($GLOBALS['userInfo']) ? $GLOBALS['userInfo'] : [];
		  //dump($userInfo);
		  $returnData="";
		  $script = ""; //JS验证的脚本
		  $attr = ""; //JS的属性
		  
		  $getFieldJs = getFieldJs(0); //获取js脚本代码
		  if($info) 
		  {
				  switch ($type)
				  {
						case "pc":
						  $tem = $info['tem_pc'];
						  break;  
						case "mobile":
						  $tem = $info['tem_mobile'];
						  break;
						default:
						  $tem = $info['tem_pc'];
				  }
				  
				  $getJsCss=getJsCss($info['js_css']);
		  }
		  
		  

		 
		  $F = new \files\File();
		  $L = new \label\Label();

		  $table = isset($info['table']) && $info['table'] ? $info['table'] : request()->param('table');
		  
		  if($id) $record = db($table) -> where('id',$id)->find();

          if(is_string($group)) $fieldWhere[]= ['group','=',$group];
		  $fieldWhere[]= ['table','=',$table];
		  $fieldWhere[]= ['status','=',1];
		  $fieldInfo = db('field_table')->where($fieldWhere)->json(['property','administrator_auth','member_auth'])-> order(['order_num','id'=>'asc'])->select();

		  foreach($fieldInfo as $key=>$val)
		  {
			    $field= getFieldInfo($val);
				
                $auth = isset($userInfo['type']) ? $field[$userInfo['type']."_auth"] : $field["member_auth"];

                if($record && count($auth['edit']) > 0)
				{
					  if(!$userInfo) continue; //如果用户没登录，不加入字段内容
					  $authEdit = $auth['edit'];

					  if(in_array("-1",$authEdit) || !in_array($userInfo['id'],$authEdit) )  continue;//如果权限有内容  
				}
				elseif(!$record && count($auth['add']) > 0)
				{
					  if(!$userInfo) continue; //如果用户没登录，不加入字段内容
					  $authAdd = $auth['add'] ;

					  if(in_array("-1",$authAdd) || !in_array($userInfo['id'],$authAdd) )  continue;//如果权限有内容  					
				}

				
				$fieldName =$field['field'];
				$formType = $field['form_type'];

                if($record && is_array($record) && count($record) > 0 )
				{
					  $field['property']['default'] = isset($record[$fieldName]) ? $record[$fieldName] : ($field['property']['is_num'] ? 0 : "" );
				}
				else
				{
					  $field['property']['default'] = isset($field['property']['default']) ? $field['property']['default'] : ($field['property']['is_num'] ? 0 : "");
				}
				
				
				/*=======================================验证信息==========================================================================*/

				 $reg = isset($field['property']['reg']) && $field['property']['reg'] ? trim($field['property']['reg']) : "";
				 $min = isset($field['property']['min']) && is_numeric($field['property']['min']) ? $field['property']['min'] : 0;
				 $max = isset($field['property']['max']) && is_numeric($field['property']['max']) ? $field['property']['max'] : 0;
				 $min_len = isset($field['property']['min_len']) && is_numeric($field['property']['min_len']) ? $field['property']['min_len'] : 0;
				 $max_len = isset($field['property']['max_len']) && is_numeric($field['property']['max_len']) ? $field['property']['max_len'] : 0;
				 $is_num = $field['property']['is_num'];
				 $fieldTitle =$field['title'];
				 if($reg || $min || $max || $min_len || $max_len || $is_num)
				 {
					   $scriptFunction = "";
					   

					   if($formType == "checkbox")
					   {
						           $script = $script.PHP_EOL."\$('[name=\"".$fieldName."[]\"]').first().attr('lay-verify','".$fieldName."');".PHP_EOL;
								   $script = $script.PHP_EOL."\$('[name=\"".$fieldName."[]\"]').attr('lay-filter','".$fieldName."');".PHP_EOL;
								   
								   if($max_len)
								   {
										   $script =$script."form.on('checkbox(".$fieldName.")', function(data){
											
												  var checkNum = \$('input[lay-filter=\"".$fieldName."\"]:checkbox:checked').length; 

												  if($max_len && checkNum > $max_len ) 
												  {
													   layer.msg('【".$fieldTitle."】-".lang('field_must_max_len',['max_len'=>$max_len])."');
													   $(data.elem).removeAttr('checked');
													   form.render('checkbox');
												  }
											});";							   
								   }
		
								   $scriptFunction = $scriptFunction.PHP_EOL."var checkNum = \$('input[lay-filter=\"".$fieldName."\"]:checkbox:checked').length;";						   
								   if($min_len && !$max_len)
								   {
										 $scriptFunction = $scriptFunction.PHP_EOL." if(checkNum < $min_len) return '【".$fieldTitle."】-".lang('field_must_min_len',['min_len'=>$min_len])."' ;";
								   }
								   elseif(!$min_len && $max_len)
								   {
										 $scriptFunction = $scriptFunction.PHP_EOL." if(checkNum > $max_len) return '【".$fieldTitle."】-".lang('field_must_max_len',['max_len'=>$max_len])."' ;";
								   }
								   elseif($min_len && $max_len)
								   {
										 $scriptFunction = $scriptFunction.PHP_EOL." if(checkNum > $max_len || checkNum < $min_len ) return '【".$fieldTitle."】-".lang('field_must_min_max_len',['min_len'=>$min_len,'max_len'=>$max_len])."' ;";
								   }
					   }
					   elseif($formType == "select" || $formType == "file")
					   {
								   $script = $script.PHP_EOL."\$('[name=\"".$fieldName."\"]').first().attr('lay-verify','".$fieldName."');".PHP_EOL;
					   
								   if($min_len)
								   {
										 $scriptFunction = $scriptFunction.PHP_EOL." if(!value || value =='0') return '【".$fieldTitle."】-".lang('required')."' ;";
								   }
					   }
					   else
					   {
						           $script = $script.PHP_EOL."\$('[name=\"".$fieldName."\"]').first().attr('lay-verify','".$fieldName."');".PHP_EOL;
								   if($is_num)
								   {
										   $scriptFunction = $scriptFunction.PHP_EOL."var regPos = /^\d+(\.\d+)?$/;".PHP_EOL."var regNeg = /^(-(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*)))$/;".PHP_EOL;
										   $scriptFunction =$scriptFunction.PHP_EOL."if(!regPos.test(value) && !regNeg.test(value)) return '【".$fieldTitle."】-".lang('field_must_num')."' ;";
										   $scriptFunction =$scriptFunction.PHP_EOL." value = value  ? Number(value) : 0;".PHP_EOL;
										   if($min && !$max)
										   {
											   $scriptFunction =$scriptFunction.PHP_EOL." if(value < $min) return '【".$fieldTitle."】-".lang('field_must_min',['min'=>$min])."' ;";
										   }
										   elseif(!$min && $max)
										   {
											   $scriptFunction =$scriptFunction.PHP_EOL." if(value < $min) return '【".$fieldTitle."】-".lang('field_must_max',['max'=>$max])."' ;";
										   }
										   elseif($min && $max)
										   {
											   $scriptFunction =$scriptFunction.PHP_EOL." if(value < $min || value < $min ) return '【".$fieldTitle."】-".lang('field_must_min_max',['min'=>$min,'max'=>$max])."' ;";
										   } 
								   }
								   else
								   {
										   $scriptFunction = $scriptFunction.PHP_EOL."var valueLen = value.length";						   
										   if($min_len && !$max_len)
										   {
												 $scriptFunction = $scriptFunction.PHP_EOL." if(valueLen < $min_len) return '【".$fieldTitle."】-".lang('field_must_min_len_str',['min_len'=>$min_len])."' ;";
										   }
										   elseif(!$min_len && $max_len)
										   {
												 $scriptFunction = $scriptFunction.PHP_EOL." if(valueLen > $max_len) return '【".$fieldTitle."】-".lang('field_must_max_len_str',['max_len'=>$max_len])."' ;";
										   }
										   elseif($min_len && $max_len)
										   {
												 $scriptFunction = $scriptFunction.PHP_EOL." if(valueLen > $max_len || valueLen < $min_len ) return '【".$fieldTitle."】-".lang('field_must_min_max_len_str',['min_len'=>$min_len,'max_len'=>$max_len])."' ;";
										   }

								   }
								   
								   if($reg)
								   {
									       $reg = str_replace(["\r\n", "\r"], "\n", $reg);
		                                   $reg = explode("\n", trim($reg));
										   
										   foreach($reg as $k => $v)
										   {
											     $regArray = [];
											     if(trim($v))
												 {
													   $regArray = explode("===", trim($v));
													   if(count($regArray)<2) $regArray[1] = lang('field_must_text');
													   $scriptFunction = $scriptFunction.PHP_EOL."var reg$k=".$regArray[0];
													   $scriptFunction = $scriptFunction.PHP_EOL."if(!reg$k.test(value) ) return '【".$fieldTitle."】-".$regArray[1]."' ;";
												 }
											   
										   }
								   }				     
					   }
					   $script=$script."form.verify({ ".PHP_EOL."$fieldName:function(value, item){ $scriptFunction".PHP_EOL." },".PHP_EOL." });";
				 }

				/*=======================================模版操作==========================================================================*/
				$temInfo = isset($tem[$fieldName]) ? $tem[$fieldName] : NULL;
				
				if($temInfo)
				{
					 $temFileName = key($temInfo); 
					 $temStr =$temInfo[$temFileName];

					 if($temFileName !="diy")
					 {
						  $temPath = getFieldTemPath($formType)."templet".DIRECTORY_SEPARATOR.$type.DIRECTORY_SEPARATOR.$temFileName.".html";
						  
						  $formTypeInfo = getFormTypeInfo($formType);
						  
						  if(!$F->f_has($temPath)) $temPath = getFieldTemPath($formType)."templet".DIRECTORY_SEPARATOR.$type.DIRECTORY_SEPARATOR.$formTypeInfo['default_'.$type].".html";
						  $temStr = $F->read($temPath);
					 } 
				}
				else
				{
					 $formTypeInfo = getFormTypeInfo($formType);
					 $temPath = getFieldTemPath($formType)."templet".DIRECTORY_SEPARATOR.$type.DIRECTORY_SEPARATOR.$formTypeInfo['default_'.$type].".html";
					 $temStr = $F->read($temPath);
				}
				/*=======================================模版操作==========================================================================*/
			    $getFormClass = new getForm($formType);

				if(isset($getFormClass->showForm) && $getFormClass->showForm) 
				{
					$temStr = call_user_func_array($getFormClass->showForm,[$temStr,$field,$record]);
				}
		        $replace_field_label =$L->replace_field_label($temStr,$field);

				if($group)
				{
					$groupType = $field['group'] ? $field['group'] : "0";
					$groupStr[$groupType] = isset($groupStr[$groupType]) ? $groupStr[$groupType].$replace_field_label : $replace_field_label;
				}
				else
				{
					$returnData = $returnData.$replace_field_label;
				}
				
		   }
		   
		   	$script = "layui.use(['jquery','jqbind','form'],function(){ 
						var $ = layui.jquery,
						jqbind = layui.jqbind,
						form = layui.form
						".$script."			
			});";
		   $returnData =$returnData .'<input name="table" type="hidden" value="'.$table.'">';
		   $returnData = $returnData.PHP_EOL.$getJsCss;
		   $returnData = $returnData.PHP_EOL.'<script>';
		   $returnData = $returnData.PHP_EOL.'layui.config({base: "__STATIC__style/module/js/",}).extend({jqelem: "jqmodules/jqelem",jqmenu: "jqmodules/jqmenu",tabmenu: "jqmodules/tabmenu",jqbind: "jqmodules/jqbind",jqtags: "jqmodules/jqtags",jqform: "jqmodules/jqform",jqcitys: "jqmodules/jqcitys"})';
		   $returnData = $returnData.PHP_EOL.$getFieldJs.PHP_EOL.$script;
		   $returnData = $returnData.PHP_EOL.'</script>';
		   
		   return $group ? ['script'=>$returnData,'form'=>$groupStr] : $returnData; 
    }	
/*************************************************************
	formSave 保存或者返回提交参数
	@param   save int  是否直接保存数据 1：直接保存到数据库中，如果有错误提示,返回格式为['err'=>1,'content'=>'错误信息'],如果保存成功['err'=>0,'content'=>'操作成功']，0：返回表单提交的数据,如果有错误提示,返回格式为['err'=>1,'content'=>'错误信息'],如果没错误信息,直接返回处理后的提交表单的数据,为数组
	@param   id int  编辑记录的id
	@param   table tring  数据表名称
    @return int
*************************************************************/	

	function formSave($id=0,$save=1,$table=NULL)
    {
		  $param =request()->param();

		  $table =$table ? $table : $param['table'];
		  
		  if(!$table)
		  {
			  $data = ['err'=>1,'content'=>lang('field_not_table')];
			  return $data;
		  }
		  
		  $userInfo = isset($GLOBALS['userInfo']) ? $GLOBALS['userInfo'] : [];
		  $fieldWhere[]= ['table','=',$table];

		  $fieldInfo = db('field_table')->where($fieldWhere)->json(['property','administrator_auth','member_auth'])-> order(['order_num','id'=>'asc'])->select();
		  
		  foreach($fieldInfo as $key=>$val)
		  {
			    $fieldName =$val['field'];
				$formType = $val['form_type'];
				
/*			    if($val['status'] != 1 && isset($param[$fieldName]) ) //字段被关闭
				{
					unset($param[$fieldName]);
					continue;
				}*/
				
			    $field= getFieldInfo($val['id']);
				/*=======================================权限检测==========================================================================*/
                $auth = isset($userInfo['type']) ? $field[$userInfo['type']."_auth"] : $field["member_auth"];

                if($id && count($auth['edit']) > 0)
				{
					  $authEdit = $auth['edit'];
					  if(!$userInfo || in_array("-1",$authEdit) || !in_array($userInfo['id'],$authEdit))
					  {
						  unset($param[$fieldName]);
						  continue; //如果用户没登录，不加入字段内容
					  }
				}
				elseif(!$id && count($auth['add']) > 0)
				{
					  $authAdd = $auth['add'] ;

					  if(!$userInfo || in_array("-1",$authAdd) || !in_array($userInfo['id'],$authAdd) )  
					  {
						  unset($param[$fieldName]);
						  continue; //如果用户没登录，不加入字段内容
					  }  					
				}

				/*=======================================验证信息==========================================================================*/
                 $is_num = $field['property']['is_num'];
				 $only = $field['property']['only'];
				 $min = isset($field['property']['min']) && is_numeric($field['property']['min']) ? $field['property']['min'] : 0;
				 $max = isset($field['property']['max']) && is_numeric($field['property']['max']) ? $field['property']['max'] : 0;
				 $min_len = isset($field['property']['min_len']) && is_numeric($field['property']['min_len']) ? $field['property']['min_len'] : 0;
				 $max_len = isset($field['property']['max_len']) && is_numeric($field['property']['max_len']) ? $field['property']['max_len'] : 0;
				 
				 $fieldTitle =$field['title'];
				 
				 if($is_num && !is_numeric(trim($param[$fieldName])) )
				 {
					  $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_num')];
					  return $data;
				 }
				 
				 if($is_num && !is_numeric(trim($param[$fieldName])) )
				 {
					  $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_num')];
					  return $data;
				 }	
				 			 
				 if($min || $max || $min_len || $max_len )
				 {
					   if($formType == "checkbox")
					   {			
					               $fieldLen = isset($param[$fieldName]) && is_array($param[$fieldName]) ? count($param[$fieldName]) : 0; 
								   if($min_len && !$max_len && $fieldLen < $min_len)
								   {
									     $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_min_len',['min_len'=>$min_len])];
										 return $data;
								   }
								   elseif(!$min_len && $max_len && $fieldLen > $max_len )
								   {
									     $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_max_len',['max_len'=>$max_len])];
										 return $data;
								   }
								   elseif($min_len && $max_len && ($fieldLen < $min_len || $fieldLen > $max_len) )
								   {
									     $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_min_max_len',['min_len'=>$min_len,'max_len'=>$max_len])];
										 return $data;
								   }
					   }
					   elseif($formType == "select" || $formType == "file")
					   {
								   if($min_len && (!isset($param[$fieldName]) || !trim($param[$fieldName]) ))
								   {
									     $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('required')];
										 return $data;
								   }
					   }
					   else
					   {
								   if($is_num)
								   {
									       $fieldValue = isset($param[$fieldName]) && is_numeric($param[$fieldName]) ? $param[$fieldName] : 0;

										   if($min && !$max && $fieldValue < $min)
										   {
											   $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_min',['min'=>$min])];
										       return $data;
										   }
										   elseif(!$min && $max && $fieldValue > $max)
										   {
											   $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_max',['max'=>$max])];
										       return $data;
										   }
										   elseif($min && $max && ($fieldValue < $min || $fieldValue > $max ) )
										   {
											   $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_min_max',['min'=>$min,'max'=>$max])];
										       return $data;
										   } 
								   }
								   else
								   {
										   $fieldLen = isset($param[$fieldName]) && trim($param[$fieldName]) ? strlen($param[$fieldName]) : 0; 					   
										   if($min_len && !$max_len && $fieldLen < $min_len)
										   {
											     $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_min_len_str',['min_len'=>$min_len])];
										         return $data;
										   }
										   elseif(!$min_len && $max_len && $fieldLen > $max_len )
										   {
											     $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_max_len_str',['max_len'=>$max_len])];
										         return $data;
										   }
										   elseif($min_len && $max_len  && ($fieldLen < $min_len || $fieldLen > $max_len) )
										   {
											     $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_must_min_max_len_str',['min_len'=>$min_len,'max_len'=>$max_len])];
										         return $data;
										   }

								   }			     
					   }

				 }
				 
				 if($only && isset($param[$fieldName]) && trim($param[$fieldName]))
				 {
					  $isOnly = valueOnly($fieldName,$param[$fieldName],$table,$id);
					  
					  if($isOnly)
					  {
						  $data = ['err'=>1,'content'=>"【".$fieldTitle."】-".lang('field_not_only')];
						  return $data;
					  }
				 }
				 
				/*=======================================字段默认值==========================================================================*/
                
				$fieldDefault = isset($field['property']['default']) ? $field['property']['default'] : "";
				$default = $is_num ? (is_numeric($fieldDefault) ? $fieldDefault : 0 ) : ($fieldDefault ? $fieldDefault : "");
				
				if(!isset($param[$fieldName]) )  $param[$fieldName] = $default;
				
				$getFormClass = new getForm($formType);
				if(isset($getFormClass->saveForm) && $getFormClass->saveForm) 
				{
					$param[$fieldName] = call_user_func_array($getFormClass->saveForm,[$param[$fieldName],request()->param()]);
				}
				/*=======================================模版操作==========================================================================*/
				
		   }
		   
		   if($save)
		   {
			     if($id)
				 {
					    $editWhere[] = ['id','=',$id];
					    $edit = db($table) -> where($editWhere) ->strict(false) ->update($param);
						
						if($edit!==false)
						{
							 $data = ['err'=>0,'content'=>lang('op_success')];
						}
						else
						{
							 $data= ['err'=>1,'content'=>lang('err_fail')];
						}
						return $data;
				 }
				 else
				 {
					    $add = db($table) -> strict(false) ->insert($param);
						
						if($add)
						{
							 $data = ['err'=>0,'content'=>lang('op_success')];
						}
						else
						{
							 $data= ['err'=>1,'content'=>lang('err_fail')];
						}
						return $data;					 
				 }
		   }
		   else
		   {
			     return $param; 
		   }
		   return $param;   
    }		
	
	class getForm
	{
		     public $showForm = NULL;
		  	 public function __construct($formType) {
				 
				  $F = new \files\File();
	              $formTypePath = getFieldTemPath($formType);

		          if($F->f_has($formTypePath."field.php") ) include $formTypePath."field.php"; 
			}	
	}
	
?>