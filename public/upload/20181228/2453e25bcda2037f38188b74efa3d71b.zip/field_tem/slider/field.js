// JavaScript Document
	layui.use(['jquery','jqbind','slider'],function(){
			var $ = layui.jquery,
			jqbind = layui.jqbind,
			slider = layui.slider,
			field=function(){
				
				this.options = {};
			}

					   /**
			 * @todo 滑块绑定
		
			 * @param string call 回调的方法
			 */
			field.prototype.slider = function(obj) {
				var _this = this;
				params = getParams($(obj), "data-params", $);
				params = $.extend({}, _this.options, params);
				var show_input =params['show_input']=="1" ? true : false; //是否显示input
				var value = params['default'] ? params['default'] : false;
				var show_type = params['show_type']=="1" ? true : false;
				var range = params['range']=="1" ? true : false;
				var showstep = params['showstep']=="1" ? true :  false;
				var step = params['step'] ? parseInt(params['step']) :  1;
				var min_ = params['min'] ? parseFloat(params['min']) :  1;
				var max_ = params['max'] ? parseFloat(params['max']) :  100;
				var color = params['color'] ? params['color'] :  false;
				var input = params['input'] ? params['input'] :  "#"+$(obj).attr('id')+"_input";
				var option = {};
				
		
				 option['elem'] = obj;
				 option['min'] = min_;  
				 option['max'] = max_; 
				 option['input'] = show_input; 
				 option['range'] = range; 
				 option['showstep'] = showstep; 
				 option['step'] = step; 
				 
				 if(value)
				 {
					  if(range)
					  {
						   var valueArray = value.split(",");
						   
						   if(valueArray.length != 2)
						   {
							   valueArray = [min_,max_];
						   }
					  }
					  else
					  {
						   var valueArray = value;
					  }
					  option['value'] = valueArray;  
				 }
				 
				 if(show_type) option['type'] = "vertical";
				 if(color) option['theme'] = color;
				 
				 option['change'] = function(vals){
					  var value_ = vals;
					  if(range) value_ = vals[0]+","+vals[1];
					  
					  $(input).val(value_);
				 }
				 
				 slider.render(option);
		
			}
			
				 /**
			 * @todo 滑块绑定器绑定
		
			 * @param string call 回调的方法
			 */
			field.prototype.sliderBind = function() {
				var _this = this;
				$(".slider:not([bind])").each(function() {
					jqbind.bind($(this));
					_this.slider(this);
				});
			}


			field.prototype.init = function() {
				var _this = this;
				_this.sliderBind();
			}
			
			
		   var sliderBind = new field();
           sliderBind.init();

   })