/*
Navicat MySQL Data Transfer

Source Server         : 测试
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : ceshi

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-09-30 16:40:11
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cowcms_field_form_type
-- ----------------------------
DROP TABLE IF EXISTS `cowcms_field_form_type`;
CREATE TABLE `cowcms_field_form_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '类型id',
  `title` varchar(255) DEFAULT NULL COMMENT '表单类型名称',
  `sign` varchar(255) DEFAULT NULL COMMENT '表单标识',
  `isdel` tinyint(3) unsigned DEFAULT '0' COMMENT '是否可删除，0：可删除，1：不可删除',
  `status` tinyint(3) unsigned DEFAULT '0' COMMENT '表单类型状态，0：关闭，1：开启',
  `order_num` int(10) unsigned DEFAULT '0' COMMENT '表单类型排序',
  `install_module` varchar(255) DEFAULT NULL COMMENT '安装模块',
  `default_pc` varchar(255) DEFAULT NULL COMMENT '默认选择电脑模版',
  `default_mobile` varchar(255) DEFAULT NULL COMMENT '默认选择手机模版',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cowcms_field_form_type
-- ----------------------------
INSERT INTO `cowcms_field_form_type` VALUES ('1', '单行文本', 'text', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('2', '多行文本', 'textarea', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('3', '选项-下拉', 'select', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('4', '选项-复选', 'checkbox', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('5', '选项-单选', 'radio', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('6', '选项-滑块', 'slider', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('7', '颜色选择器', 'colorpicker', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('8', '星级评分', 'rate', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('9', '日期时间', 'datetime', '1', '1', '0', '', '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('10', '上传-单文件', 'file', '1', '1', '0', null, '1', '1');
INSERT INTO `cowcms_field_form_type` VALUES ('11', '编辑器', 'editor', '1', '1', '0', null, '1', '1');

-- ----------------------------
-- Table structure for cowcms_field_scheme
-- ----------------------------
DROP TABLE IF EXISTS `cowcms_field_scheme`;
CREATE TABLE `cowcms_field_scheme` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '方案id',
  `title` varchar(255) DEFAULT NULL COMMENT '方案名称',
  `table` varchar(255) DEFAULT NULL COMMENT '方案的数据表名称',
  `sign` varchar(255) DEFAULT NULL COMMENT '方案标识',
  `isdel` tinyint(3) unsigned DEFAULT '0' COMMENT '是否可删除，0：可删除，1：不可删除',
  `describe` text COMMENT '方案描述',
  `tem_pc` text COMMENT '电脑模板',
  `tem_mobile` text COMMENT '手机模板',
  `js_css` text COMMENT '额外的样式文件',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cowcms_field_scheme
-- ----------------------------

-- ----------------------------
-- Table structure for cowcms_field_table
-- ----------------------------
DROP TABLE IF EXISTS `cowcms_field_table`;
CREATE TABLE `cowcms_field_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '字段id',
  `field` varchar(255) DEFAULT NULL COMMENT '字段名称',
  `title` varchar(255) DEFAULT NULL COMMENT '字段别名',
  `status` tinyint(3) unsigned DEFAULT '0' COMMENT '字段状态，0：关闭，1：开启',
  `table` varchar(255) DEFAULT NULL COMMENT '字段所在的数据表',
  `order_num` int(10) unsigned DEFAULT '0' COMMENT '字段显示排序，越小越在前边，默认为0',
  `form_type` varchar(255) DEFAULT NULL COMMENT '字段表单类型，input,select,checkbox等',
  `group` varchar(255) DEFAULT NULL COMMENT '表单显示的分组',
  `describe` varchar(255) DEFAULT NULL COMMENT '字段描述，最多100个字',
  `only` tinyint(3) unsigned DEFAULT '0' COMMENT '字段是否值唯一，0：不唯一，1：唯一',
  `administrator_auth` text COMMENT '管理组的权限，格式为json ',
  `member_auth` text COMMENT '用户组的权限，格式为json',
  `property` text COMMENT '字段属性，格式为json',
  `isdel` tinyint(3) unsigned DEFAULT '0' COMMENT '字段是否可以删除，0：可以删除，1：不可以删除，默认为0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cowcms_field_table
-- ----------------------------
