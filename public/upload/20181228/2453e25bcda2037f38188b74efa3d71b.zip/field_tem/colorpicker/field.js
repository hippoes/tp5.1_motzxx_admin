// JavaScript Document
	layui.use(['jquery','jqbind','colorpicker'],function(){
			var $ = layui.jquery,
			jqbind = layui.jqbind,
			colorpicker = layui.colorpicker,
			field=function(){
				
				this.options = {};
			}
			 /**
			 * @todo 颜色选择器绑定
			 * @param string call 回调的方法
			 */
			field.prototype.colorpicker = function(obj) {
				var _this = this;
				params = getParams($(obj), "data-params", $);
				params = $.extend({}, _this.options, params);
				var alpha =params['alpha'] ? params['alpha'] : null;
				var value = params['default'] ? params['default'] : (alpha=="1" ? "rgba(68,66,66,0.5)" : "#fff");
				var predefine = params['predefine'] ? true : false;
				var colors = params['colors'] ? params['colors'].split(",") : [];
				var size = params['size'] ? params['size'] :  "sm";
				var input = params['input'] ? params['input'] :  "#"+$(obj).attr('id')+"_input";
				var option = {};
				
		
				 option['elem'] = obj;
				 option['color'] = value;
				 option['size'] = size;
				 
				 if(alpha=="1")
				 {
					 option['format'] = "rgb";
					 option['alpha'] = true;
				 }
				 
				 if(predefine =="1")
				 {
					  option['predefine'] = true;
					  
					  if(colors.length > 0) option['colors'] = colors;
				 }
				 
				 option['done'] = function(color){
					  $(input).val(color);
					  color || this.change(color); //清空时执行 change
				 }
				 
				 option['change'] = function(color){
					  $(input).val(color);
				 }
				 
				 colorpicker.render(option);
		
			}
			
				 /**
			 * @todo 颜色选择器绑定
		
			 * @param string call 回调的方法
			 */
			field.prototype.colorpickerBind = function() {
				var _this = this;
				$(".colorpicker:not([bind])").each(function() {
					jqbind.bind($(this));
					_this.colorpicker(this);
				});
			}
	
	
			field.prototype.init = function() {
				var _this = this;
				_this.colorpickerBind();
			}
			
			
		   var colorpickerBind = new field();
           colorpickerBind.init();

   })