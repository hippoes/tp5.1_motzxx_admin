<?php
return [
      'name' =>'字段管理系统',
	  'author' =>'COWCMS',
	  'version' =>'5.1',
	  'qq' =>'360881323',
	  'web' =>'http//open.cowcms.com',
	  'describe'=>'主要负责管理数据表字段，生成form表单和添加编辑form表单数据，以及管理提交字段的权限',
	  'sign'=>'XrmvNJ3B8Cq53ox7jyc9VCtA1jcag1ZxIyKc'

];
