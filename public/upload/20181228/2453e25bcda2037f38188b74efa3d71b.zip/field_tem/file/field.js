// JavaScript Document
	layui.use(['jquery','jqbind','upload'],function(){
			var $ = layui.jquery,
			jqbind = layui.jqbind,
			upload = layui.upload,
			field=function(){
				
				this.options = {upload_url:"{:url('field/Upload/upload')}"};
			}

	        /**
			 * @todo 单文件上传
		
			 * @param string call 回调的方法
			 */
			field.prototype.fileUpload = function(obj,uploadUrl) {
				var _this = this;
				params = getParams($(obj), "data-params", $);
				params = $.extend({}, _this.options, params);

                uploadUrl = params['upload_url'];

				var field =params['field']; 
				var server =params['server'] ? params['server'] : 0; 
				var type =params['type'] ? params['type'] : "file"; 
				var exts = params['exts'] ? params['exts'] : false;
				var size = params['size'] && !isNaN(params['size']) ? parseInt(params['size']) : false;
				var auto = params['auto']=="1" ? true : false;
				
				var img = params['img'];
				var text = params['text'];
				
				var input = params['input'] ? params['input'] :  "#"+$(obj).attr('id')+"_input";
				var uploadButton = params['uploadButton'] ? params['uploadButton'] :  false;
				
				var value = params['default'] ? params['default'] :  false;
		
				var option = {};
				
		
				 option['elem'] = obj;
				 option['url'] = uploadUrl; 
				 option['accept'] = "file"; 
				 
				 if(exts) option['exts'] = exts;
				 if(size) option['size'] = size;
				
				 option['bindAction'] = uploadButton;
				 option['field'] = field;
				 
				 if(auto)
				 {
					 option['auto'] = true;
					 $(uploadButton).hide();
				 }
				 else
				 {
					 option['auto'] = false;
					 $(uploadButton).show();
				 }
				 
				 option['before']= function(obj){
					  obj.preview(function(index, file, result){
							if($(img).length > 0)  $(img).attr('src', result); //图片链接（base64）
					  });
				 }
				 
				 option['done']= function(res, index, upload){

					  if(res.code == 0){
						  if($(input).length > 0) $(input).val(res.data.src);
						  if($(text).length>0) $(text).html('');
					  }
					  else
					  {
						  return layer.msg(res.msg);
					  }
				 }
				 
				 option['error']= function(index, upload){
					 
					 if($(text).length>0)
					 {
						  var textMsg = $(text);
						  textMsg.html('<a class="layui-btn layui-btn-xs '+field+'_reload">重试</a>');
						  textMsg.find('.'+field+'_reload').on('click', function(){
							  uploadInst.upload();
						  });
					 }
		
				 }
				 
				var uploadInst =  upload.render(option);
		
			}
			
	        /**
			 * @todo 单文件上传
		
			 * @param string call 回调的方法
			 */
			field.prototype.fileGallery = function(obj) {
				var _this = this;
				params = getParams($(obj), "data-params", $);
				params = $.extend({}, _this.options, params);
				
				var field =params['field']; 
				var server =params['server'] ? params['server'] : 0; 

				
				if(server=="1")
				{
					 $(obj).on('click',function(){
						        var url = "{:url('upload/Upload/upload_list',['selecttype'=>1,'fielstype'=>'file'])}"+"?recallelement="+field+"_input";
						   		var uploadindex = layer.open({
										type:2,//类型
										shade:0.3, //遮罩层透明度
										area:["80%","80%"],
										title:"上传",
										content: url
									});
					 })
				}
				else
				{
					$(obj).hide();
				}
				
		
			}			
			/**
			 * @todo 单文件上传
		
			 * @param string call 回调的方法
			 */
			field.prototype.fileUploadBind = function(uploadUrl) {
				var _this = this;
				$(".fileUpload:not([bind])").each(function() {
					jqbind.bind($(this));
					_this.fileUpload(this,uploadUrl);
				});
				
				$(".fileGallery:not([bind])").each(function() {
					jqbind.bind($(this));
					_this.fileGallery(this);
				});
			}
			
			/**
			 * @todo 单文件上传
		
			 * @param string call 回调的方法
			 */
			field.prototype.init = function() {
				var _this = this;
				_this.fileUploadBind();
			}
			
			
		   var fileUploadBind = new field();
           fileUploadBind.init();

   })