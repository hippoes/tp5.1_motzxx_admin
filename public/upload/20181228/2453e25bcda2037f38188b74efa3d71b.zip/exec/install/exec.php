<?php

//安装完成执行函数
/*******************************************************************************
@param   $module_name 安装模块名称 
@param   $post 提交的表单数据  
@param   $data  data['begin'] 为begin函数返回的数据  data['sqlBegin']  sqlBegin函数返回的值   data['sqlEnd'] sqlEnd函数返回的值; 
*******************************************************************************/
$this->finish = function($module_name,$post,$data)
{
    
	$moduleList = getModuleList(['module','install','admin']);
	
	foreach($moduleList as $v)
	{
		  $field = getModuleExec($v,'field');
		  
		  if($field && isInstall($v)) addFormType($field,$v);
	}
	

};

?>