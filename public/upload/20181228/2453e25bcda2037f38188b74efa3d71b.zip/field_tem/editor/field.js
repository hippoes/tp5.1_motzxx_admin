// JavaScript Document
// JavaScript Document
	layui.use(['jquery','jqbind','layedit'],function(){
			var $ = layui.jquery,
			jqbind = layui.jqbind,
			layedit = layui.layedit,
			field=function(){
				
				this.options = {upload_url:"{:url('field/Upload/upload')}"};
			}
	        /**
			 * @todo 绑定编辑器
		
			 * @param string call 回调的方法
			 */
			field.prototype.editor = function(obj,uploadUrl) {
				var _this = this;
				params = getParams($(obj), "data-params", $);
				params = $.extend({}, _this.options, params);
		
		        height = params
				var height = params['height'] ? params['height'] :  200;
				height = !isNaN(height) ? height : 200;
				var option = {uploadImage:{},height:height};
				option['uploadImage']['url'] =params['upload_url'];
				option['uploadImage']['type'] ="post";
				
				
		        var layeditIIndex = layedit.build(obj,option);
				
				$(window.frames["LAY_layedit_"+layeditIIndex].document).on('keyup',function(){
					$(obj).val(layedit.getContent(layeditIIndex))
				});
		
			}
			
				 /**
			 * @todo 编辑器
		
			 * @param string call 回调的方法
			 */
			field.prototype.editorBind = function(uploadUrl) {
				var _this = this;
				$(".editor:not([bind])").each(function() {
					jqbind.bind($(this));
					_this.editor(this,uploadUrl);
				});
			}
	
	
			field.prototype.init = function() {
				var _this = this;
				_this.editorBind();
			}
			
			
		   var editorBind = new field();
           editorBind.init();

   })