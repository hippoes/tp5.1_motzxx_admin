<?php
/*************************************************************
	fieldAdd 添加字段
	@param   fieldInfo array  要判断的字段名称
    @return int
*************************************************************/	
$this -> fieldAdd=function($fieldInfo){

	   $field_info=[];
	   
	   if(count($fieldInfo) <=0) return 0;
	   
	   $field = isset($fieldInfo['field']) && $fieldInfo['field'] ? $fieldInfo['field'] : NULL;
	   $table = isset($fieldInfo['table']) && $fieldInfo['table'] ? $fieldInfo['table'] : NULL;
	   
	   $formType = isset($fieldInfo['form_type']) && $fieldInfo['form_type'] ? $fieldInfo['form_type'] : NULL;
	   
	   $is_num = isset($fieldInfo['property']['is_num']) && $fieldInfo['property']['is_num'] ? $fieldInfo['property']['is_num'] : 0;
	   $min = isset($fieldInfo['property']['min']) && $fieldInfo['property']['min'] ? $fieldInfo['property']['min'] : 0;
	   $decimal_num = isset($fieldInfo['property']['decimal_num']) && $fieldInfo['property']['decimal_num'] ? $fieldInfo['property']['decimal_num'] : 0;
	   $default = isset($fieldInfo['property']['default']) && $fieldInfo['property']['default'] ? $fieldInfo['property']['default'] : "";
	   
	   $min_len = isset($fieldInfo['property']['min_len']) && $fieldInfo['property']['min_len'] ? $fieldInfo['property']['min_len'] : 0;
	   
	   $describe = isset($fieldInfo['describe']) && $fieldInfo['describe'] ? $fieldInfo['describe'] : "";
	   
	   if(!$field || !$table || !$formType) return 0;
	   
	   try{
				
				$field_info['field'] = $field;
				$field_info['table'] = $table;
				$field_info['default'] = $default;
				$field_info['comment'] = $describe;
				$field_info['is_null'] = 1;
                $field_info['type'] = "varchar";
				
				$Field = new \database\Field();
                $create = $Field -> field_create($field_info);
				return $create==1 ? 1 : 0;
		}catch(\Exception $e){
			   return 0;
		}
	
};

/*************************************************************
	fieldEdit 添加字段
	@param   fieldInfo array  要判断的字段名称
    @return int
*************************************************************/	
$this -> fieldEdit=function($fieldInfo){

	   $field_info=[];
	   
	   if(count($fieldInfo) <=0) return 0;
	   
	   $field = isset($fieldInfo['field']) && $fieldInfo['field'] ? $fieldInfo['field'] : NULL;
	   $table = isset($fieldInfo['table']) && $fieldInfo['table'] ? $fieldInfo['table'] : NULL;
	   
	   $formType = isset($fieldInfo['form_type']) && $fieldInfo['form_type'] ? $fieldInfo['form_type'] : NULL;
	   
	   $is_num = isset($fieldInfo['property']['is_num']) && $fieldInfo['property']['is_num'] ? $fieldInfo['property']['is_num'] : 0;
	   $min = isset($fieldInfo['property']['min']) && $fieldInfo['property']['min'] ? $fieldInfo['property']['min'] : 0;
	   $decimal_num = isset($fieldInfo['property']['decimal_num']) && $fieldInfo['property']['decimal_num'] ? $fieldInfo['property']['decimal_num'] : 0;
	   $default = isset($fieldInfo['property']['default']) && $fieldInfo['property']['default'] ? $fieldInfo['property']['default'] : "";
	   
	   $min_len = isset($fieldInfo['property']['min_len']) && $fieldInfo['property']['min_len'] ? $fieldInfo['property']['min_len'] : 0;
	   
	   $describe = isset($fieldInfo['describe']) && $fieldInfo['describe'] ? $fieldInfo['describe'] : "";
	   
	   if(!$field || !$table || !$formType) return 0;
	   
	   try{
				
				$field_info['field'] = $field;
				$field_info['table'] = $table;
				$field_info['default'] = $default;
				$field_info['comment'] = $describe;
				$field_info['is_null'] = 1;
                $field_info['type'] = "varchar";
				
				$Field = new \database\Field();
                $edit = $Field -> field_edit($field_info);
				return $edit==1 ? 1 : 0;
		}catch(\Exception $e){
			   return 0;
		}
	
};	


/*************************************************************
	fieldDel 删除字段
	@param   fieldInfo array  要判断的字段名称
    @return int
*************************************************************/	
$this -> fieldDel=function($fieldInfo){

	   $field_info=[];

	   if(count($fieldInfo) <=0) return 0;
	   
	   $field = isset($fieldInfo['field']) && $fieldInfo['field'] ? $fieldInfo['field'] : NULL;
	   $table = isset($fieldInfo['table']) && $fieldInfo['table'] ? $fieldInfo['table'] : NULL;
	   
	   if(!$field || !$table) return 0;
	   
	   try{
				
				$field_info['field'] = $field;
				$field_info['table'] = $table;

				$Field = new \database\Field();
                $del = $Field -> field_del($field_info);
				return $del==1 ? 1 : 0;
		}catch(\Exception $e){
			   return 0;
		}
	
};	
					
?>