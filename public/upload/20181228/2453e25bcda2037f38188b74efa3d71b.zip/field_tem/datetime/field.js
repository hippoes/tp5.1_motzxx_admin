// JavaScript Document
	layui.use(['jquery','jqbind','laydate'],function(){
			var $ = layui.jquery,
			jqbind = layui.jqbind,
			laydate = layui.laydate,
			field=function(){
				
				this.options = {};
			}

	
		    /**
			 * @todo 日期时间
		
			 * @param string call 回调的方法
			 */
			field.prototype.datetime = function(obj) {
				var _this = this;
				params = getParams($(obj), "data-params", $);
				params = $.extend({}, _this.options, params);
				var lang =params['lang']=="1" ? "en" : false; 
				var calendar = params['calendar'] =="1" ? true : false;
				var range = params['range']=="1" ? true : false;
				var type = params['type'] ? params['type'] : "date";
				var color = params['color'] ? params['color'] :  false;
				
				var min_ = params['min'] ? params['min'] :  false;
				var max_ = params['max'] ? params['max'] :  false;
				
				var value = params['default'] ? params['default'] :  false;
				
				var format = params['format'] ? params['format'] :  false;
				var input = params['input'] ? params['input'] :  false;
				var option = {};
				
		
				 option['elem'] = obj;
				 option['type'] = type; 
				 if(color) option['theme'] = color;
				 if(lang) option['lang'] = lang;
				 if(format) option['format'] = format;
				 if(calendar) option['calendar'] = true;
				 if(range) option['range'] = true;
				 if(range) option['range'] = true;
				 if(min_) option['min'] = !isNaN(min_) ?  parseInt(min_) : min_;
				 if(max_) option['max'] = !isNaN(max_) ?  parseInt(max_) : max_;
				 
				 if(value)
				 {
					 option['value'] = value;  
					 option['isInitValue'] = true; 
				 }
				 
				option['done']= function(value, date){
					  if(input) $(input).val(value);
				}
				 
				 laydate.render(option);
		
			}
			
				 /**
			 * @todo 日期时间
		
			 * @param string call 回调的方法
			 */
			field.prototype.datetimeBind = function() {
				var _this = this;
				$(".datetime:not([bind])").each(function() {
					jqbind.bind($(this));
					_this.datetime(this);
				});
			}
	
	
			field.prototype.init = function() {
				var _this = this;
				_this.datetimeBind();
			}
			
			
		   var datetimeBind = new field();
           datetimeBind.init();

   })